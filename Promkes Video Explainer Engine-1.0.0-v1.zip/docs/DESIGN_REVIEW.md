# DESIGN REVIEW — plugin `promkes` v1.0.0

Label bukti: **[DIUJI]** dijalankan di sesi pembuatan · **[DIAMATI]** terbaca langsung di spesifikasi V3.0 · **[INFERENSI]** kesimpulan saya · **[BELUM DIUJI]** belum ada bukti. Keterangan format dan pemasangan plugin berasal dari tutorial pihak ketiga yang mengutip dokumentasi Anthropic dan **belum** diverifikasi ke dokumentasi resmi.

## 1. Ringkasan eksekutif
- **Hasil**: 12 skill (9 modul orkestrator/spesialis + 3 entry `start`, `resume`, `qa`), 1 sub-agent QA, 3 skrip Python (pustaka standar saja), skema + contoh manifest, 9 berkas referensi.
- **Bukti**: `selftest.py` 35/35 lulus, termasuk deteksi 16 cacat yang sengaja disuntikkan ke validator [DIUJI]; 12/12 skill lolos `quick_validate` [DIUJI]; contoh manifest 0 FAIL dan 3 WARN yang memang disengaja [DIUJI].
- **Tiga risiko terbesar**: (1) belum ada uji end-to-end pada proyek video nyata; (2) verifikasi klaim kesehatan bergantung pada akses web dan penilaian model; (3) kehabisan konteks pada STANDARD/ADVANCED — pembuatan plugin ini sendiri sempat terpotong sebelum selesai [DIAMATI].
- **Rekomendasi**: pilot LITE pada satu poster nyata sebelum dipakai produksi (bagian 5); selama pilot gunakan rute REFERENCE_ONLY atau HANDOFF_ONLY.

## 2. Temuan pada spesifikasi sumber: akar masalah → perbaikan
| ID | Temuan [bukti] | Akar masalah | Perbaikan di plugin | Sisa risiko |
|---|---|---|---|---|
| F-01 | Satu dokumen sangat panjang dimuat utuh setiap kali [DIAMATI] | prompt monolit tanpa pemuatan bertahap | 9 skill (SKILL.md 24–66 baris), referensi dimuat per fase | salah-routing skill (R-04) |
| F-02 | Dua penomoran keluaran: O01–O14 (§2.2) vs OUTPUT 01–17 (§8.2) [DIAMATI] | dua daftar disusun terpisah | OUTPUT 01–17 jadi kanonis + peta O → OUTPUT | – |
| F-03 | FRAME_RATE variabel wajib, tetapi §3.3 tak memberi default FPS [DIAMATI] | default tak selaras dengan registry | 30 fps berlabel DEFAULTED, reversibel | default bisa tak cocok target |
| F-04 | "Kebijakan pembulatan eksplisit" diwajibkan (§8.4) tetapi tak didefinisikan [DIAMATI] | kewajiban tanpa definisi | half-up pada batas kumulatif, rentang half-open; helper `frames` + validator | – |
| F-05 | Timing hidup di beberapa tempat (Scene Record detik+frame, `scene_timing`, cue audio/subtitle) padahal timestamp bertentangan dilarang [DIAMATI] | beberapa representasi tanpa aturan rekonsiliasi | frames kanonis di `scene_timing`; `scene_sequence` dilarang memuat timing; `package` membandingkan scenes.json ↔ manifest | scenes.json yang terlambat diperbarui → FAIL terdeteksi |
| F-06 | Manifest wajib punya tipe/enum/null/cross-reference, namun tak ada skema; klaim validasi mesin dilarang tanpa validator, jadi mustahil dipenuhi [DIAMATI] | spesifikasi menuntut bukti yang tak bisa dihasilkannya | `manifest.schema.json` + `promkes_validate.py` | validator hanya struktural/aritmetika (R-06) |
| F-07 | Enum status klaim bercampur bahasa (`BELUM_DIVERIFIKASI` di antara kode Inggris) [DIAMATI] | penamaan tak konsisten | dipertahankan verbatim demi kompatibilitas; validator menolak nilai di luar enam | varian salah ketik ("UNVERIFIED") ditolak — disengaja |
| F-08 | "ID stabil" diwajibkan, tanpa tata ID [DIAMATI] | – | grammar ID + pola pada skema untuk ID utama | ID sekunder hanya konvensi |
| F-09 | Tak ada mekanisme state/resume untuk pipeline 14 fase; EC-RESOURCE tanpa prosedur [DIAMATI] | spesifikasi mengandaikan satu sesi cukup | `project_state.json`, `RESUME.md` otomatis, hash artefak, batch + `progress` | hilang maksimal satu batch; sandbox chat direset (R-03) |
| F-10 | "Independent QA" dikerjakan model/konteks yang sama; spesifikasi sendiri menyatakan skill bukan agen otonom [DIAMATI §1.2; INFERENSI] | independensi hanya nominal | QA dari berkas + sub-agent berkonteks bersih bila ada; pernyataan batas independensi | di chat biasa agent tak berjalan (R-11) |
| F-11 | 12 capability check diwajibkan tanpa cara memeriksa [DIAMATI] | model cenderung mengklaim kemampuan | `capabilities` memprobe runtime; sisi-model tetap NOT_TESTED sampai dicoba | probe hanya mencakup runtime lokal |
| F-12 | VERIFIED menuntut sumber "benar-benar diakses", tanpa protokol [DIAMATI] | tanpa akses web mustahil dipenuhi | protokol S02; BELUM_DIVERIFIKASI sebagai default; VERIFIED wajib `evidence_refs` (divalidasi) | mutu penilaian bukti (R-02) |
| F-13 | Tujuh Guide tanpa pemilik; S13 "tidak mengambil alih authoring" tanpa definisi indeks [DIAMATI] | peran indeks vs penulis tak dibedakan | `mcg.json` sebagai indeks; pemilik usulan berlabel | pemilik perlu disetujui |
| F-14 | "Estimasi durasi realistis" tanpa ukuran [DIAMATI] | – | heuristik kata/detik berlabel ESTIMATED + kalibrasi di Fase 09 | angka heuristik bisa meleset (R-08) |
| F-15 | Remotion disebut tanpa kontrak adapter [DIAMATI] | risiko halusinasi API | checklist adapter + pemetaan konsep NOT_CHECKED; tak ada templat kode yang tak teruji | kode dibuat per proyek, UNVERIFIED sampai dikompilasi |
| F-16 | Ketergantungan antarfase implisit padahal perubahan hulu wajib menginvalidasi hilir [DIAMATI §8.8] | – | DAG fase di state, STALE otomatis, `--no-propagate` beralasan | granularitas satu fase = satu unit |
| F-17 | Status scene dan defect tanpa enum; RENDER_ROUTE tanpa default [DIAMATI] | – | enum di skema; REFERENCE_ONLY default | – |
| F-18 | Atribut variabel mencampur sifat statis (tipe, validasi) dan per-proyek (Source, State) [INFERENSI] | – | registry statis di referensi; instance di state | – |

**Cacat desain yang saya temukan pada pekerjaan sendiri** [DIUJI]: (a) menyelesaikan ulang Fase 00 hanya untuk menyegarkan probe membuat semua fase hilir STALE → diperbaiki: probe ulang memperbarui hash tanpa propagasi, dan pengecualian `--no-propagate` wajib beralasan dan tercatat; (b) tiga skill entry memakai kunci frontmatter yang ditolak `quick_validate` → diganti ke kunci standar (kehilangan `argument-hint` dan `disable-model-invocation`, mengorbankan sedikit kenyamanan demi portabilitas).

## 3. Keputusan plugin di luar spesifikasi (berlabel DEFAULTED, semuanya reversibel)
D-01 30 fps · D-02 half-up pada batas kumulatif dan rentang half-open · D-03 rute default REFERENCE_ONLY · D-04 heuristik ≈ 2,2 kata/detik (rentang kasar 1,8–2,6; bukan fakta terukur) · D-05 OUTPUT 01–17 sebagai penomoran kanonis · D-06 enum scene/defect/lifecycle/hak · D-07 pemilik tujuh Guide (usulan) · D-08 Fase 11 default SKIPPED · D-09 skema ID · D-10 `--no-propagate` sebagai pengecualian tercatat · D-11 isi skill berbahasa Indonesia, enum dan ID tetap Inggris · D-12 tidak mengirim templat kode renderer.

## 4. Sisi negatif hasil: register risiko dan tindakan
P×D: T tinggi · S sedang · R rendah.
| ID | Sisi negatif | P×D | Preventif | Antisipatif (tanda dini) | Solutif | Mitigatif |
|---|---|---|---|---|---|---|
| R-01 | Belum teruji end-to-end; mutu keluaran skill belum terbukti [BELUM DIUJI] | T×T | pilot LITE satu poster sebelum produksi | metrik pilot (bagian 5) meleset | iterasi skill dari temuan; tambah fault-injection untuk tiap defect nyata | tetap REFERENCE_ONLY/HANDOFF_ONLY sampai lulus |
| R-02 | Verifikasi klaim kesehatan keliru atau terlalu percaya diri | S×T | BELUM_DIVERIFIKASI sebagai default; VERIFIED wajib `evidence_refs`; klaim ditahan tak masuk screenplay | VERIFIED tanpa sumber otoritatif, sumber lama, atau satu sumber saja | tinjauan profesional kesehatan; turunkan status; `touch 02` | Fact Lock menahan; tak ada klaim persetujuan klinis |
| R-03 | Kehabisan token/konteks pada STANDARD/ADVANCED walau ada resume; sandbox chat direset antar-tugas | T×S | LITE default; chat hanya receipt; batch + `progress`; unduh folder tiap sesi | `begin` memperingatkan fase berat; respons mulai terpotong | `/promkes:resume` atau tempel `RESUME.md` + unggah folder | RESUME.md selalu mutakhir; hilang maksimal satu batch |
| R-04 | Salah-routing skill atau tak terpicu (12 skill, deskripsi dwibahasa) [BELUM DIUJI] | S×S | deskripsi spesifik domain promkes; skill entry eksplisit | skill terpicu di luar konteks promkes atau tak terpicu pada permintaan promkes | persempit deskripsi; panggil `/promkes:…` | skill entry eksplisit |
| R-05 | Jalur skrip berbeda antarpermukaan (chat, Cowork, Claude Code) [diuji hanya di sandbox ini] | S×S | pencarian berlapis (`CLAUDE_PLUGIN_ROOT`, `/mnt`, `~/.claude`) + salinan `tools/` per proyek | `find` tak menemukan apa pun | beri path manual; salin skrip | pustaka standar saja: dapat dijalankan dari mana pun |
| R-06 | Rasa aman palsu: "PASS" dikira "benar" | S×T | pesan PASS menyebut lingkupnya; qa-handoff menegaskan batas | PASS dikutip sebagai persetujuan | tambah uji semantik | ceiling bukan keputusan; persetujuan manusia dicatat terpisah |
| R-07 | State rusak atau diedit manual → resume keliru | R×S | tulis atomik + `.bak`; hash artefak | `status` menandai CHANGED/MISSING atau gagal baca | rollback `.bak`; `touch` | RESUME.md dibuat ulang otomatis |
| R-08 | Heuristik kata/detik meleset → VO tak muat | S×R | label ESTIMATED | durasi ukur menyimpang jauh dari estimasi di Fase 09 | kalibrasi dari sampel TTS/pengisi suara | revisi pacing, bukan menjejalkan dialog |
| R-09 | Ekspektasi "langsung jadi MP4" padahal tidak ada render | S×S | README dan status pengiriman jujur; default REFERENCE_ONLY | permintaan render tanpa target platform | susun adapter per proyek setelah versi dicek + proof render | HANDOFF tetap bernilai (prompt + manifest) |
| R-10 | Pemetaan Remotion usang atau salah [BELUM DIUJI] | S×S | label NOT_CHECKED; verifikasi versi wajib | proof render gagal | koreksi dari dokumentasi versi terpasang | fallback HANDOFF |
| R-11 | QA kurang independen di chat (agent hanya di Cowork/Claude Code) | T×S | QA dari berkas + pernyataan batas | agent tak tersedia | jalankan QA di sesi/konteks baru | tinjauan manusia di L5 |
| R-12 | Rantai pasok: skrip berjalan dengan izin pengguna | R×T | pustaka standar, tanpa jaringan, tanpa `shell=True`, kecil dan terbaca | perubahan skrip tanpa review | tinjau diff; jalankan di sandbox | skrip tak memegang kredensial atau jaringan |
| R-13 | Pembaruan plugin tak terterapkan (laporan pihak ketiga soal unggah ulang) [INFERENSI] | R×S | naikkan `version` setiap rilis | versi lama masih aktif | hapus lalu pasang ulang | state mencatat `tools_version` |
| R-14 | Skill berbahasa Indonesia menyulitkan pemeliharaan non-ID; balasan bisa campur bahasa | R×R | ID dan enum tetap Inggris; README | respons campur bahasa | tambah terjemahan skill | – |
| R-15 | Kepatuhan: video kesehatan resmi sering butuh persetujuan institusi | S×T | persetujuan manusia terpisah; tak ada klaim approval | publikasi sebelum persetujuan | tarik publikasi; ulang QA | status jelas di handoff |
| R-16 | Overhead 14 fase untuk video pendek | T×R | LITE default; Fase 11 SKIPPED; MCG-Lite | pengguna melewati fase | `skip` beralasan | – |

## 5. Evaluasi: cara menilai plugin ini
**Protokol pilot (LITE, REFERENCE_ONLY, satu poster nyata dari topik yang tim kuasai)**: `/promkes:start` → fase demi fase sampai Fase 12 → serahkan ke peninjau kesehatan.
| Metrik | Cara ukur | Ambang go |
|---|---|---|
| Kalimat faktual tanpa claim ID | validator `FACT_WITHOUT_CLAIM` + QA manual | 0 |
| FAIL validator pada paket akhir | `promkes_validate.py package` | 0 |
| Uji resume paksa | hentikan sesi di tengah Fase 08, lanjutkan di sesi baru | tak ada fase DONE yang diulang |
| Klaim berbahaya lolos | tinjauan profesional kesehatan | 0 (jumlah klaim yang diturunkan statusnya dicatat) |
| Drift identitas karakter | rubrik manual 1–5 per referensi hasil generasi | ditetapkan tim sebelum pilot |
| Intervensi manual per fase, waktu, dan token | log sesi | dicatat sebagai garis dasar |
**Go/no-go**: lanjut ke STANDARD hanya bila tiga baris pertama terpenuhi dan tak ada klaim berbahaya lolos. **Regresi**: jalankan `selftest.py` setelah setiap perubahan skrip; tiap defect nyata dari pilot ditambahkan sebagai fault-injection baru.

## 6. Peta cakupan: spesifikasi → plugin
| Spesifikasi | Lokasi di plugin |
|---|---|
| §1.1–1.2 identitas, otoritas | `promkes-orchestrator/SKILL.md` |
| §1.3 spesialis S01–S13 | `references/phases-and-gates.md` §1 + 9 skill |
| §2.1–2.2 tujuan, keluaran | `phases-and-gates.md` (penomoran OUTPUT) |
| §2.3 kedalaman · §2.4 rute | orchestrator (Fase 00), `visual-continuity`, `phases-and-gates.md` §3 |
| §3.1–3.5 mode, variabel, default, klasifikasi, status klaim | `variables-enums-defaults.md`, `set-var`, `init` |
| §4 Fase 00–13 | skill per fase + DAG di `promkes_state.py` |
| §5 guardrails | `guardrails.md` + pemeriksaan validator |
| §6 edge case | `recovery-and-states.md` §1–2 |
| §7 kriteria selesai, state machine | `recovery-and-states.md` §3–5 + ceiling `package` |
| §8.1 ringkasan eksekutif · §8.9 prinsip keluaran | orchestrator "Format keluaran" |
| §8.2 daftar keluaran | `phases-and-gates.md` |
| §8.3 Reference Prompt Record · §8.4 Scene Record | `ids-traceability-records.md` §3 + pemeriksaan `package` |
| §8.5 manifest | `manifest.schema.json`, `manifest.example.json`, validator |
| §8.6 paket kode · §8.7 laporan QA | `promkes-renderer-manifest`, `promkes-qa-handoff` |
| §8.8 keterlacakan | `ids-traceability-records.md` §2 + state |

## 7. Bukti uji
**[DIUJI]**: kompilasi 3 skrip · `selftest.py` 35/35 (14 cacat manifest + 2 cacat klaim terdeteksi; pembulatan half-up; init, gerbang prasyarat, deteksi hash, propagasi STALE, `--no-propagate`, re-probe tanpa propagasi, RESUME.md, `package`, helper `frames`) · contoh manifest 0 FAIL/3 WARN · `quick_validate` 12/12 · pemeriksaan nama/panjang deskripsi/tautan referensi.
**[BELUM DIUJI]**: pemasangan di Cowork atau Claude Code; menu `/` memunculkan skill entry; kualitas pemicu otomatis skill; perilaku `$ARGUMENTS`; sub-agent berjalan; `capabilities` di Windows/macOS/Cowork; pemetaan Remotion; `ffprobe` pada berkas nyata; pembuatan gambar referensi; proyek end-to-end; kebenaran isi kesehatan dan mutu visual; verifikasi format plugin ke dokumentasi resmi.

## 8. Keputusan terbuka untuk pemilik
1. Setujui atau ubah pemilik tujuh Guide (D-07). 2. Konfirmasi default 30 fps, rute REFERENCE_ONLY, dan 2,2 kata/detik (D-01, D-03, D-04). 3. Target renderer pertama (mis. Remotion) agar adapter bisa diverifikasi pada versi nyata. 4. Lisensi plugin (kosong saat ini). 5. Pertahankan enum `BELUM_DIVERIFIKASI` campur bahasa atau normalkan. 6. Tambahkan terjemahan Inggris untuk skill?

**Verifikasi kemasan [DIUJI]**: `promkes.plugin` dibuka ke folder sementara dan `selftest.py` dijalankan dari salinan itu: 35/35 lulus; 12 SKILL.md, 1 agent, tanpa `__pycache__`.
