# Compiler B (video) dan C (adapter & preflight)

## B. Video Generation Prompt Compiler (opsional)
Aktif hanya bila `RENDER_ROUTE` = NATIVE_AI_VIDEO atau HYBRID (atau diminta) **dan** target mendukung jenis generasinya (text-to-video / image-to-video). Keluaran: prompt video global; prompt per scene (subject/action/context, gerak kamera, instruksi motion, pencahayaan, start/end state, durasi, kontinuitas, negative constraints, reference conditioning). Setiap prompt mandiri. Gerak diambil dari `motion_spec.json` (nama easing dan timing), bukan kurva karangan.

`08_prompts/video_generation/video_prompts.json`:
```json
{"video_prompts":[{"video_prompt_id":"VID-SC-03","scene_id":"SC-03","mode":"T2V|I2V","prompt":"…",
 "negative_constraints":["…"],"duration_seconds":3.5,"start_state_ref":"REF-KEY-03","end_state_ref":null,
 "camera":"…","motion_ref_ids":["MOT-03-01"],"reference_conditioning":["REF-CHR-01","REF-STY-01"],
 "target_model":null,"target_version":null,"unsupported_controls":[],"status":"PROMPT_DRAFT"}]}
```
Preflight tambahan: durasi klip vs batas model (UNKNOWN bila belum diketahui) · untuk I2V, berkas referensi start/end harus nyata ada · konflik antara prompt video dan referensi gambar.

## C. Prompt Adapter & Preflight Compiler
Menyesuaikan format prompt dengan target, mengelola reference ID, menguji kelengkapan, memisahkan unsupported controls, dan menghasilkan capability map serta batas pemakaian.

`adapter/capability_map.md` — tabel: **Kontrol/fitur** · **Didukung** (YES / NO / UNKNOWN) · **Sumber bukti** (dokumentasi resmi, uji nyata) · **Dampak** · **Perlakuan**. UNKNOWN tidak ditebak. Fitur yang lazim diperiksa: input gambar referensi dan jumlahnya, rasio/resolusi, durasi maksimum, negative prompt, seed atau kontrol konsistensi, kontrol kamera, teks dalam gambar.

Bila `TARGET_PLATFORM` / `TARGET_MODEL` / `TARGET_MODEL_VERSION` belum diketahui: keluarkan prompt **platform-neutral** dan nyatakan batasnya; jangan memakai sintaks atau parameter khusus platform.
