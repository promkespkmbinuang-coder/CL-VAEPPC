---
name: promkes-prompt-reference
description: Fase 08 pipeline promkes (S08). Kompilasi prompt gambar-diam untuk referensi (style, karakter, ekspresi, pose, lingkungan, properti, scene keyframe, overlay art), prompt video-generation opsional (text-to-video/image-to-video), serta adapter dan preflight prompt per platform/model target, lengkap dengan Reference ID, negative constraints, dan lifecycle yang jujur. Gunakan setelah storyboard dan motion terkunci untuk membuat paket prompt-to-reference video kesehatan. English - prompt-to-reference compilers with preflight and platform adapter.
---

# Promkes — Prompt & Reference Engineering (S08)

Prasyarat: Fase 05, 06, 07 DONE. Baca `visual_style_guide.md`, `mcg.json`, `scenes.json`, `motion_spec.json`. Ada tiga compiler berbeda; **jangan mencampur** prompt gambar-diam, prompt video, dan kode renderer dalam satu artefak (model memperlakukannya sebagai perintah yang bertabrakan).

Keluaran: `08_prompts/still_reference/references.json` (OUTPUT 09–11) · `08_prompts/video_generation/video_prompts.json` (OUTPUT 12; hanya NATIVE_AI_VIDEO/HYBRID atau bila diminta) · `08_prompts/adapter/capability_map.md` · `08_prompts/preflight_report.md`. Bentuk rekaman: `promkes-orchestrator/references/ids-traceability-records.md` §3.

## A. Reference Prompt Compiler (gambar diam)
Paket: (1) Master Reference Prompt global dari MVSG → (2) Character Reference Pack: master, front/side/back bila perlu, expression sheet, pose sheet, wardrobe, constraint kontinuitas → (3) Environment & Props Pack: location reference, background plate, object, prop, variasi lingkungan → (4) Scene Keyframe Prompt Pack: **satu prompt = satu gambar**.

Setiap prompt scene keyframe wajib menyebut: Reference ID · Scene ID · subject · captured visual state · pose · environment · composition · camera viewpoint · lighting · palette · aspect ratio · character/style lock · negative constraints.

Aturan penulisan (alasan di dalam kurung):
- **Mandiri**: memuat deskripsi karakter dan gaya lengkap, bukan "seperti sebelumnya" (prompt akan ditempel ke platform lain tanpa konteks chat).
- **Hanya gambar diam**: tanpa perintah video berkelanjutan ("animate", "pan across", "transition to"); itu milik compiler B.
- **Zona teks dibiarkan kosong** ("papan kosong tanpa tulisan"): teks faktual dirender sebagai overlay oleh renderer (model gambar sering menghalusinasi huruf dan angka).
- Rujuk ID dan versi lock (`STY-01@v1`, `CHR-01@v1`), tulis `allowed_variations`.

Negative constraints baseline (selalu ada; tambahkan yang spesifik): tanpa teks atau tipografi tertanam · tanpa logo/watermark kecuali aset resmi · tanpa citra menakutkan atau gore · tanpa stereotip · tanpa kemiripan orang nyata · tanpa desain karakter off-model · tanpa anatomi rusak atau anggota tubuh berlebih · tanpa angka dosis atau elemen medis berbahaya yang tak terverifikasi.

```text
[REF-KEY-03 | SC-03 | SCENE_KEYFRAME | 9:16 1080x1920]
Subjek: <CHR-01 deskripsi lengkap + ekspresi>. Keadaan visual yang ditangkap: <momen beku>.
Pose: <…>. Lingkungan: <ENV-01 deskripsi>. Komposisi: <…>. Viewpoint kamera: <…>. Pencahayaan: <…>. Palet: <hex+peran>.
Kunci: gaya STY-01@v1, karakter CHR-01@v1 — pertahankan proporsi, kostum, bahasa bentuk. Zona teks kosong.
Negatif: <baseline + spesifik>.
```
**Lifecycle jujur**: `status` = PROMPT_DRAFT → PROMPT_REVIEWED (setelah preflight lulus) → GENERATION_PENDING. GENERATED_UNREVIEWED, SELECTED, APPROVED hanya bila berkas nyata ada dan tercatat di blok `asset` (path + sha256). Bila gambar tak bisa dibuat di sini, berhenti di PROMPT_REVIEWED dan tandai `IMAGE_GENERATION_STATUS`. Jangan menyatakan gambar dibuat bila baru berupa prompt.

## B dan C — video prompt, adapter, preflight platform
Baca `references/video-prompts-and-adapter.md` bila rute memerlukannya. Jangan mengarang parameter atau kemampuan platform; UNKNOWN tetap UNKNOWN sampai diperiksa.

## F. Preflight (wajib sebelum PROMPT_REVIEWED)
Periksa ambiguitas · konflik antarprompt · unsupported controls · kompatibilitas referensi · risiko drift karakter · informasi scene yang hilang · pembuatan visual tak disengaja · risiko halusinasi teks. `preflight_report.md`: prompt · cek · hasil (PASS/HOLD) · tindakan. HOLD satu prompt tidak menghentikan prompt lain. Validasi struktur: `python tools/promkes_validate.py package` (REF_FIELD_MISSING, REF_NEGATIVE_MISSING, DANGLING_REF).

## Setelah selesai
`complete 08 --artifact 08_prompts/still_reference/references.json --artifact 08_prompts/preflight_report.md --artifact 08_prompts/adapter/capability_map.md --lock REFERENCE_PROMPT_LOCK=v1` (tambahkan `video_prompts.json` bila ada). Fase berat: kerjakan 3–5 referensi per batch dan `progress 08 --note …`.

## Larangan
Mengarang parameter platform · menghapus negative constraints · prompt video di dalam file referensi gambar · menjanjikan konsistensi karakter sempurna · meminta model gambar menulis teks faktual.
