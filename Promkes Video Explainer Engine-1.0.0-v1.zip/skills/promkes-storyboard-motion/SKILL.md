---
name: promkes-storyboard-motion
description: Fase 06-07 pipeline promkes. (S06) Storyboard dan sinematografi - scene contract, shot list, framing, angle, komposisi, fokus, pencahayaan, kontinuitas masuk/keluar, hitung frame dengan FPS dan pembulatan eksplisit; (S07) spesifikasi motion renderer-neutral - state awal, key pose, jalur gerak, timing, easing, transisi, dipisah per kelas (karakter, objek, lingkungan, kamera, transisi). Gunakan setelah screenplay dan style guide terkunci. English - storyboard, scene contracts, and motion specification.
---

# Promkes — Storyboard & Cinematography (S06), Motion (S07)

Prasyarat Fase 06: 04 dan 05 DONE (baca `screenplay.md`, `visual_style_guide.md`, `mcg.json`). Fase 07: 06 DONE.

## Fase 06 → `06_storyboard/scenes.json`, `storyboard.md` (OUTPUT 07)
`scenes.json` berisi **Scene Record** (daftar kolom di `promkes-orchestrator/references/ids-traceability-records.md` §3). Setiap scene wajib punya: scene ID dan urutan · story beat · durasi · waktu mulai/selesai · rujukan fakta (`source_fact_refs`, `claim_refs`) · shot (ukuran, angle, viewpoint, komposisi, fokus, pencahayaan) · ID karakter/lingkungan/properti · reference ID · overlay ID untuk teks layar · cue audio · kontinuitas masuk/keluar · `guide_versions`.

**Aturan timing** (sumber tunggal): hitung dengan skrip, jangan dengan perkiraan kepala.
```bash
python tools/promkes_validate.py frames --fps 30 --durations 3,5.5,3.5 --json
```
Detik adalah turunan; frame kanonis (half-up pada batas kumulatif, rentang half-open). Total durasi seluruh scene harus sesuai `VIDEO_DURATION`. Jangan membuat timecode presisi tanpa dasar: isi `timing_basis` (PLANNED / ESTIMATED / MEASURED) di manifest nanti. Teks faktual selalu lewat overlay yang menunjuk claim ID; reference ID boleh menunjuk referensi yang baru dibuat di Fase 08 (daftarkan dulu, Fase 08 memenuhinya).

`storyboard.md` hanya tampilan tabel turunan dari JSON (jangan menjadikannya sumber kedua).

## Fase 07 → `07_motion/motion_spec.json` (OUTPUT 08)
Satu entri per elemen bergerak, **renderer-neutral** (tanpa API renderer), dipisah per kelas: character · object · environment · camera · transition.
```json
{"motion":[{"motion_ref_id":"MOT-03-01","scene_id":"SC-03","element_id":"CHR-01","element_class":"CHARACTER",
 "initial_state":"…","start_pose":"…","trigger":"…","action":"…","motion_path":"…","transform":{"position":"…","scale":"…","rotation":"…"},
 "timing":{"frame_start":255,"frame_end":300},"easing":{"name":"ease-in-out","params":null},"hold_frames":6,
 "follow_through":"…","end_pose":"…","end_state":"…","transition":null,"dependency":[],"continuity_state":"…"}]}
```
Easing ditulis sebagai nama + parameter, bukan kurva per-frame. Gerak subjek, objek, dan kamera dipisahkan. Referensi motion **terpisah** dari prompt gambar-diam.

## Setelah selesai
```bash
python tools/promkes_state.py complete 06 --artifact 06_storyboard/scenes.json --artifact 06_storyboard/storyboard.md --lock STORYBOARD_LOCK=v1
python tools/promkes_state.py complete 07 --artifact 07_motion/motion_spec.json --lock MOTION_LOCK=v1
```
Fase berat bila scene banyak: kerjakan per 3–5 scene dan `progress 06 --note "SC-01..05 selesai"`.

## Larangan
Timecode tanpa dasar · timing berbeda di dua tempat · motion yang tidak punya state awal/akhir · mencampur motion ke dalam prompt gambar diam · teks faktual di dalam gambar (bukan overlay).
