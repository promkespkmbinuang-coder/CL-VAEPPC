---
name: start
description: Mulai proyek video explainer promkes baru - intake materi, pemeriksaan kemampuan, pemilihan kedalaman, dan pembuatan folder proyek beserta state. Gunakan ketika pengguna mengetik /promkes:start atau meminta memulai proyek video explainer promosi kesehatan baru.
---

# /promkes:start

Argumen pengguna (abaikan bila tertulis literal `$ARGUMENTS`): $ARGUMENTS

Ikuti skill `promkes-orchestrator`, bagian **Fase 00**:
1. Catat materi yang dilampirkan atau disebut (poster, infografis, caption, naskah, audio). Berkas yang hanya disebut belum tentu ada: periksa dulu. Tentukan `INPUT_MODE`.
2. Tentukan judul kerja dan kedalaman (default LITE bila tidak disebut). Tanyakan hanya yang material dan hilang — maksimal satu pertanyaan.
3. Temukan toolbox dan jalankan `init` (perintah ada di skill orchestrator, bagian Toolbox); lalu `capabilities`.
4. Isi variabel yang diketahui dengan `set-var`; biarkan default berlabel DEFAULTED.
5. `complete 00 --artifact 00_intake/capabilities.json`, lalu tampilkan receipt: lokasi folder proyek, depth/route, default yang dipakai, variabel wajib yang belum terisi, dan langkah berikutnya (`begin 01`).
Jangan memulai Fase 01 sebelum pengguna menyetujui ringkasan intake, kecuali ia sudah meminta "langsung jalankan".
