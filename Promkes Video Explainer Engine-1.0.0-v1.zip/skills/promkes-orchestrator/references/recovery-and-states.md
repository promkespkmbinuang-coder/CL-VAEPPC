# Pemulihan, status, dan kriteria selesai

## 1. Kelas pengecualian dan respons bawaan
| Kelas | Arti | Respons bawaan |
|---|---|---|
| EC-MISSING | materi wajib tidak ada | DEFAULTED bila aman dan reversibel; selain itu REQUEST_CLARIFICATION (satu pertanyaan, hanya bila material) |
| EC-AMBIGUOUS | beberapa tafsir material | kerjakan tafsir terbaik, nyatakan asumsi (ASSUMPTION); tanya hanya bila taruhannya tinggi |
| EC-CONFLICT | poster/caption/naskah/audio bertentangan | catat semua versi (CONFLICTED); rekonsiliasi sebelum fact lock; HOLD klaim terdampak (P1) |
| EC-INVALID | input atau schema tidak sesuai | REJECT_INPUT atau perbaiki di pemilik; validator FAIL = tidak lanjut |
| EC-STALE | referensi atau versi usang | verifikasi ulang (web search bila tersedia); `touch` fase terdampak |
| EC-CAPABILITY | platform/model tak punya kemampuan | FALLBACK: prompt saja + `IMAGE_GENERATION_STATUS`, atau handoff renderer-neutral |
| EC-PERMISSION | izin tidak ada | STOP/ESCALATE; retry tidak boleh dipakai untuk menghindari penolakan izin |
| EC-EXECUTION | proses gagal | RETRY terbatas (maks 2) lalu PARTIAL_RESULT dengan pengungkapan; jangan sembunyikan kegagalan |
| EC-PARTIAL | sebagian keluaran berhasil | PARTIAL_RESULT; status PARTIAL, bukan PASS |
| EC-RESOURCE | batas token/waktu/ukuran tercapai | **checkpoint**: `progress`, `resume-prompt`, berhenti di batas batch; lanjutkan di sesi baru |

## 2. Kebijakan pemulihan
P0 CRITICAL → stop dan eskalasi · P1 HIGH → HOLD komponen terdampak (`hold <fase>`; fase independen boleh jalan dengan `begin --force` + alasan di history) · P2 MEDIUM → fallback aman atau hasil parsial dengan pengungkapan · P3 LOW → koreksi lokal dan ungkapkan bila material. Aksi: REJECT_INPUT, REQUEST_CLARIFICATION, RETRY, FALLBACK, PARTIAL_RESULT, ROLLBACK (`project_state.json.bak`), ESCALATE, STOP.

Aturan khusus: gambar referensi tak bisa dibuat → hasilkan prompt dan tandai `IMAGE_GENERATION_STATUS` · renderer tak tersedia → handoff renderer-neutral · platform belum diketahui → jangan buat kode spesifik-platform · karakter tak konsisten → kembali ke S05/S13 dan validasi ulang asset references · durasi tak realistis → revisi pacing atau durasi, bukan memaksakan dialog · klaim kesehatan bermasalah → tahan hanya bagian terdampak dan jangan memperkuatnya lewat adaptasi kreatif · jangan menghapus kegagalan atau menyamarkannya sebagai keberhasilan parsial.

## 3. Empat keadaan selesai (jangan dicampur)
A. **Prompt design completion** — semua prompt dan spesifikasi tersusun. B. **Reference handoff readiness** — prompt, ID, referensi, motion, manifest, handoff lolos pemeriksaan statis. C. **Render readiness** — platform, schema, kemampuan, dependensi diperiksa. D. **Rendered artifact completion** — file video/audio nyata ada dan inspeksi wajib dilakukan.

### Definition of Done
- **Prompt/Reference**: source tercatat · fakta terkunci atau ditahan eksplisit · story & storyboard selesai · Visual Guide & continuity references sesuai · reference prompts lengkap · motion terpisah · manifest renderer-neutral lengkap · negative constraints ada · batas platform dinyatakan · QA statis selesai.
- **Renderer Code**: platform & versi diketahui · target schema diperiksa · struktur kode & dependensi terdokumentasi · scene/asset ID valid dalam cakupannya · pemetaan frame/waktu konsisten · berkas & aset teridentifikasi · validasi statis dijalankan bila runtime ada · hasil tes aktual dan yang belum dijalankan dipisahkan.
- **Render**: file ada dan bisa dibuka · metadata diperiksa · durasi sesuai · stream video/audio diperiksa · visual & audio diperiksa sesuai kemampuan · sinkron A/V diperiksa bila memungkinkan · blocker kritis selesai. Bukti dicatat di `13_handoff/render_evidence.json` (`file_path`, `checks`: opens, metadata, duration, streams, visual_inspection, audio_inspection, av_sync, critical_blockers_resolved).

## 4. State machine pengiriman (satu status akhir)
BLUEPRINT_ONLY → REFERENCE_READY → RENDER_READY → RENDERED_PARTIALLY_VERIFIED → RENDERED_VERIFIED; BLOCKED bila ada hambatan kritis. `promkes_validate.py package` menghitung **ceiling** dari bukti; M00 memilih status ≤ ceiling. **NOT_RUN, UNKNOWN, NOT_VERIFIED, BLOCKED, dan PARTIAL tidak boleh diubah menjadi PASS.**

## 5. Persetujuan manusia (dicatat terpisah)
NOT_REQUESTED · PENDING · APPROVED · REJECTED · NOT_APPLICABLE. Jangan menyatakan persetujuan klinis, institusional, legal, atau publikasi tanpa bukti otorisasi manusia; ceiling tidak pernah menyiratkan persetujuan.
