# Fase, kepemilikan, dan gerbang

Penomoran keluaran memakai **OUTPUT 01–17** (spesifikasi §8.2). Seri O01–O14 (§2.2) dipetakan: O09 → OUTPUT 09–11, O10 → 12, O11 → 13, O12 → 14, O13 → 15, O14 → 16–17; sisanya sama nomor.

## 1. Kepemilikan spesialis (single ownership)
| ID | Spesialis | Skill pelaksana | Fase | Memiliki |
|---|---|---|---|---|
| M00 | Master Orchestrator | promkes-orchestrator | 00, 13 | integrasi akhir, state, gerbang, status pengiriman |
| S01 | Source & Asset Intelligence | promkes-source-health | 01 | OUTPUT 01 Source Material Dossier |
| S02 | Health Evidence & Safety Auditor | promkes-source-health | 02 | OUTPUT 02 Health Truth Registry & Fact Lock |
| S03 | Audience & Campaign Strategy | promkes-campaign-screenplay | 03 | OUTPUT 03 Campaign Creative Brief |
| S04 | Story & Screenplay Architect | promkes-campaign-screenplay | 04 | OUTPUT 04 Screenplay & VO |
| S05 | Visual Identity & Art Direction | promkes-visual-continuity | 05 | OUTPUT 05 Master Visual Style Guide |
| S13 | Master Continuity Guardian | promkes-visual-continuity | 05 + tiap perubahan kanon | OUTPUT 06 MCG & locks (mengindeks, tidak menulis ulang guide pemilik) |
| S06 | Storyboard & Cinematography | promkes-storyboard-motion | 06 | OUTPUT 07 |
| S07 | Animation & Motion Design | promkes-storyboard-motion | 07 | OUTPUT 08 |
| S08 | Prompt & Reference Engineering (compiler A/B/C) | promkes-prompt-reference | 08 | OUTPUT 09–12 |
| S09 | Audio Intelligence & Sound Engineering | promkes-audio-subtitle | 09 | OUTPUT 15 |
| S10 | Renderer, Composition & Code | promkes-renderer-manifest | 10 | OUTPUT 13 (manifest), 14 (adapter/kode) |
| S11 | Social Accessibility & Distribution (kondisional) | promkes-audio-subtitle | 11 | materi publikasi |
| S12 | Independent QA | promkes-qa-handoff (+ agent promkes-qa-auditor) | 12 | OUTPUT 16 QA & defect |

## 2. Fase, dependensi, keluaran, gerbang keluar
| Fase | Nama | Depends | Keluaran (di dalam folder proyek) | Gerbang keluar |
|---|---|---|---|---|
| 00 | Intake & Capability | – | `00_intake/capabilities.json`; variabel di state | variabel material tercatat; capability jujur |
| 01 | Source Intelligence | 00 | `01_source/source_dossier.md` | tidak ada teks yang ditebak; konflik sumber tercatat |
| 02 | Health Truth Lock | 01 | `02_health/health_truth_registry.json`, `fact_lock.md` | tiap klaim berstatus; FACT_LOCK=vN atau HOLD eksplisit |
| 03 | Campaign Architecture | 02 | `03_campaign/creative_brief.md` | satu pesan inti; objektif; CTA |
| 04 | Story & Screenplay | 02, 03 | `04_screenplay/{original_script,screenplay,vo_script,onscreen_copy,subtitle_transcript}.md` | klaim ber-ID; durasi realistis; SCREENPLAY_LOCK |
| 05 | Visual Identity & Continuity | 04 | `05_visual/visual_style_guide.md`, `mcg.json` (+ `guides/` bila ADVANCED) | STYLE_LOCK, CONTINUITY_LOCK; ID kanonis stabil |
| 06 | Storyboard & Cinematography | 04, 05 | `06_storyboard/scenes.json`, `storyboard.md` | total durasi = target; frame math valid; STORYBOARD_LOCK |
| 07 | Motion Design | 06 | `07_motion/motion_spec.json` | motion terpisah per kelas; MOTION_LOCK |
| 08 | Prompt & Reference | 05, 06, 07 | `08_prompts/still_reference/references.json`, `video_generation/video_prompts.json` (opsional), `adapter/capability_map.md`, `preflight_report.md` | preflight lulus atau HOLD; prompt mandiri; negative constraints ada |
| 09 | Audio Engineering | 04, 06 | `09_audio/audio_spec.md`, `audio_assets.json` | provenance timing; kelas presisi; status hak |
| 10 | Renderer Script & Code | 06, 07, 08, 09 | `10_renderer/manifest.json`, `adapter_check.md`, `code/` (bila diminta & didukung) | validator manifest 0 FAIL; adapter dicek atau NOT_CHECKED |
| 11 | Accessibility & Distribution | 04, 09 | `11_distribution/*` (default SKIPPED) | kondisional; tanpa janji viralitas |
| 12 | Independent QA | 10 | `12_qa/qa_report.md`, `qa_matrix.json`, `defects.json` | tak ada P0 terbuka; status jujur |
| 13 | Final Integration & Handoff | 12 | `13_handoff/final_status.md`, `render_evidence.json` (bila ada render) | satu delivery state ≤ ceiling |

Fase 10 selalu menghasilkan manifest renderer-neutral (juga pada REFERENCE_ONLY); hanya *kode* renderer yang bersyarat.

## 3. Output Routes
REFERENCE_ONLY (gambar referensi, prompt referensi, scene contract, manifest) · NATIVE_AI_VIDEO (prompt t2v/i2v sesuai kemampuan platform) · PROGRAMMATIC_RENDERER (manifest, composition spec, kode renderer bila target & schema tersedia) · HYBRID (gabungan) · HANDOFF_ONLY (paket teknis tanpa klaim render).
