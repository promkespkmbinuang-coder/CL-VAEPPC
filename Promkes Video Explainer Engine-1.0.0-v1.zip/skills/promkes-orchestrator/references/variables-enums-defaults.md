# Variable Registry, enum, dan default

Atribut **statis** (tipe, arti, wajib, validasi, dependensi, dampak) ada di tabel ini. Atribut **per-proyek** (Source, State, nilai) disimpan di `project_state.json` lewat `set-var --state … --source …`.

## 1. Registry
| Variabel | Tipe — arti | Wajib | Default | Validasi | Bergantung pada | Dampak jika hilang |
|---|---|---|---|---|---|---|
| PROJECT_ID | string — pengenal stabil | wajib | dibuat `init` | `^PRJ-[A-Za-z0-9-]+$` | – | keterlacakan putus |
| PROJECT_TITLE | string — judul kerja | wajib | – | non-kosong | – | folder/manifest tanpa nama |
| INPUT_MODE | enum — sumber utama | wajib | – | 4 nilai | materi | Fase 01 tak tahu sumber otoritatif |
| CAMPAIGN_TOPIC | string — topik kesehatan | wajib | – | non-kosong | S01 | S02/S03 tanpa fokus |
| TARGET_AUDIENCE | string — audiens, literasi, konteks | wajib | – | spesifik | S03 | bahasa dan visual tak terarah |
| COMMUNICATION_OBJECTIVE | string — tujuan pengetahuan/sikap/perilaku | wajib | – | satu tujuan utama | audiens | pesan menyebar |
| KEY_MESSAGE | string — satu pesan inti | wajib | – | 1 kalimat; terhubung claim ID | fact lock | pesan tenggelam |
| CTA | string — ajakan perilaku prioritas | wajib | – | tindakan konkret & aman | fact lock | video tanpa arah |
| LANGUAGE | string — bahasa VO/teks | wajib | Bahasa Indonesia mudah dipahami | – | audiens | VO tak sesuai |
| LOCAL_LANGUAGE_PREFERENCE | string — preferensi bahasa/budaya lokal | opsional | – | tanpa dialek karangan/stereotip | LANGUAGE | netral |
| VIDEO_TYPE | string — jenis video | wajib | – | – | – | gaya tak terarah |
| TARGET_PLATFORM | string — platform AI/renderer | kondisional | – | tidak boleh ditebak | RENDER_ROUTE | kode platform = NOT_CHECKED |
| TARGET_MODEL | string — model generasi | kondisional | – | tidak ditebak | PLATFORM | prompt tak teradaptasi (compiler C) |
| TARGET_MODEL_VERSION | string — versi | kondisional | – | tidak ditebak | MODEL | batas kemampuan UNKNOWN |
| VIDEO_DURATION | detik — durasi target | wajib | 45 | > 0 | – | pacing tak terukur |
| ASPECT_RATIO | `W:H` | wajib | 9:16 | konsisten dgn RESOLUTION | – | komposisi salah |
| RESOLUTION | `WxH` | wajib | 1080x1920 | konsisten dgn ASPECT_RATIO | – | – |
| FRAME_RATE | fps | wajib | **30** (keputusan plugin; spesifikasi §3.3 tidak memberi default) | > 0 | – | konversi frame tak terdefinisi |
| RENDER_ROUTE | enum | wajib | REFERENCE_ONLY (keputusan plugin) | 5 nilai | platform | keluaran tak terarah |
| ART_DIRECTION | string | wajib | diturunkan dari arahan kreatif yang disetujui | – | S03/S05 | gaya tak terkunci |
| CHARACTER_REFERENCE | path/string | opsional | – | hak pakai jelas | – | karakter dirancang baru |
| ENVIRONMENT_REFERENCE | path/string | opsional | – | hak pakai jelas | – | lingkungan dirancang baru |
| AUDIO_SOURCE | path | kondisional | – | kemampuan decode diperiksa | – | timing hanya ESTIMATED |
| TRANSCRIPT_SOURCE | string | kondisional | – | provenance wajib | AUDIO_SOURCE | timing tak bisa dipertanggungjawabkan |
| TIMING_PRECISION | enum | wajib | ESTIMATED | sesuai bukti | audio | SRT/VTT tak boleh diekspor |
| RENDERER_SCHEMA | path/string — kontrak input renderer | kondisional | – | harus diperiksa, bukan JSON generik | PLATFORM | kode = NOT_CHECKED |
| OUTPUT_FORMAT | string | kondisional | – | didukung target | PLATFORM | ekspor tak terdefinisi |
| *ORIENTATION* | enum | wajib | portrait | – | – | – |
| *VOICE_STYLE* | string | opsional | hangat, natural, jelas, percakapan | – | – | – |
| *MUSIC_POLICY* | string | opsional | orisinal atau berlisensi yang sesuai | tidak boleh dianggap berlisensi | – | risiko hak |
| *SUBTITLE_POLICY* | string | opsional | mudah dibaca; sinkron bila timing didukung | timing harus akuntabel | – | – |
| *PRODUCTION_DEPTH* | enum | wajib | LITE | LITE/STANDARD/ADVANCED | – | – |

Baris bercetak miring = default §3.3 yang diperlakukan sebagai variabel. Jangan mengasumsikan platform, model, versi, parameter API, atau kemampuan render yang tidak diketahui.

## 2. Enum (nilai persis; jangan diterjemahkan)
- **State variabel**: PROVIDED, CONFIRMED, INFERRED, DEFAULTED, MISSING, CONFLICTED, NOT_APPLICABLE.
- **Klasifikasi sumber**: USER_PROVIDED, OBSERVED, VERIFIED (hanya bila sumber benar-benar diakses), INFERENCE, ASSUMPTION, CREATIVE, UNKNOWN, CONFLICTED.
- **Status klaim kesehatan** (verbatim dari spesifikasi, termasuk campuran bahasa): VERIFIED, PARTIALLY_SUPPORTED, MIXED_OR_CONTESTED, BELUM_DIVERIFIKASI, CONTRADICTED, UNKNOWN.
- **Input mode**: POSTER_FIRST, AUDIO_FIRST, SCRIPT_FIRST, HYBRID. **Depth**: LITE, STANDARD, ADVANCED. **Route**: REFERENCE_ONLY, NATIVE_AI_VIDEO, PROGRAMMATIC_RENDERER, HYBRID, HANDOFF_ONLY.
- **Capability**: VERIFIED, UNAVAILABLE, NOT_TESTED, NOT_APPLICABLE. Kunci: image_file_access, visual_analysis, audio_decode, metadata, asr, diarization, transcript_alignment, reference_image_generation, code_execution, renderer_availability, export, media_inspection.
- **Presisi timing**: WORD, PHRASE, SEGMENT, ESTIMATED, NONE. **Dasar timing scene**: MEASURED, ESTIMATED, PLANNED.
- **Tipe referensi**: STYLE, CHARACTER, EXPRESSION, POSE, ENVIRONMENT, PROP, SCENE_KEYFRAME, OVERLAY_ART, OTHER. **Lifecycle**: PROMPT_DRAFT, PROMPT_REVIEWED, GENERATION_PENDING, GENERATED_UNREVIEWED, SELECTED, APPROVED, REJECTED, MISSING, BLOCKED.
- **Hak**: OWNED, LICENSED, ORIGINAL_GENERATED, UNKNOWN, NOT_LICENSED, NOT_APPLICABLE. **Status QA**: PASS, FAIL, PARTIAL, NOT_VERIFIED, NOT_RUN, NOT_APPLICABLE.
- **Status fase** (state): PENDING, IN_PROGRESS, DONE, HOLD, BLOCKED, STALE, SKIPPED.

## 3. Keputusan plugin yang melengkapi celah spesifikasi (berlabel DEFAULTED, reversibel)
1. **Timing kanonis = frames.** `frame = round_half_up(detik × fps)` pada batas kumulatif; rentang half-open `[frame_start, frame_end)`; scene berurutan tanpa celah/tumpang-tindih; `total_frames = round_half_up(durasi × fps)`. Detik adalah turunan. Hitung dengan `promkes_validate.py frames`.
2. **Heuristik kecepatan VO** (bukan fakta): mulai dari ≈ 2,2 kata/detik untuk narasi Indonesia (rentang kasar 1,8–2,6), sudah termasuk jeda; label ESTIMATED; ganti dengan hasil ukur dari sampel TTS atau pengisi suara. Bila hasil tak muat durasi, revisi pacing atau durasi — jangan menjejalkan dialog.
3. **Skema ID** dan konvensi berkas: lihat `ids-traceability-records.md`.
