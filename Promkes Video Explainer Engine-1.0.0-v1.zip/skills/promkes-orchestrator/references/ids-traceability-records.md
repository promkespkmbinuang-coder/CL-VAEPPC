# ID, keterlacakan, dan rekaman kanonis

## 1. Skema ID (stabil; tidak dipakai ulang)
| Jenis | Pola | Contoh | | Jenis | Pola | Contoh |
|---|---|---|---|---|---|---|
| Proyek | `PRJ-…` | PRJ-20261113-stunting | | Motion | `MOT-SS-NN` | MOT-03-01 |
| Sumber | `SRC-NN` | SRC-01 | | Overlay | `OVL-SS-NN` | OVL-02-01 |
| Klaim | `CLM-NNN` | CLM-001 | | Audio | `AUD-{VO,SFX,BGM,AMB}-NN` | AUD-VO-01 |
| Scene | `SC-NN` | SC-03 | | Subtitle | `SUB-NNN` | SUB-012 |
| Shot | `SHT-SS-NN` | SHT-03-01 | | Layer | `LYR-SS-NN` | LYR-02-02 |
| Karakter / Lingkungan / Properti / Gaya | `CHR-NN` / `ENV-NN` / `PRP-NN` / `STY-NN` | CHR-01 | | Transisi | `TRN-SS-SS` | TRN-02-03 |
| Referensi | `REF-TTT-NN[A]`, TTT ∈ STY CHR EXP POS ENV PRP KEY OVL OTH | REF-KEY-03A | | Defect / Item terbuka / Uji | `DEF-NNN` / `OI-NNN` / `T-NNN` | DEF-004 |
| Guide | MCHG MCPG MVSG MNSG MVAG MWEG SCG + `@vN` | MVSG@v1 | | Lock | `NAMA=vN` | FACT_LOCK=v1 |

Lock: FACT_LOCK, SCREENPLAY_LOCK, STYLE_LOCK, CONTINUITY_LOCK, STORYBOARD_LOCK, MOTION_LOCK, REFERENCE_PROMPT_LOCK, MANIFEST_LOCK. Tujuh Guide: MCHG Master Character Guide · MCPG Character/Personality Profile · MVSG Master Visual Style Guide · MNSG Master Narrative Style Guide · MVAG Master Voice & Audio Guide · MWEG Master World & Environment Guide · SCG Scene Continuity Guide.

## 2. Rantai keterlacakan (§8.8)
INPUT → SOURCE → CLAIM → FACT_LOCK → CAMPAIGN_MESSAGE → SCREENPLAY → SCENE → REFERENCE_PROMPT → GENERATED_ASSET → MOTION_REFERENCE → RENDERER_MANIFEST → RENDERER_CODE → ARTIFACT → QA → HUMAN_APPROVAL. Setiap rekaman material punya ID stabil. Perubahan hulu menginvalidasi dan memvalidasi ulang hanya tahap turunan yang terdampak (`touch`), termasuk regression test kritis.

## 3. Bentuk berkas kanonis (JSON adalah sumber; tampilan `.md` hanyalah turunan)
**`02_health/health_truth_registry.json`**
```json
{"schema_version":"1.0",
 "fact_lock":{"version":"v1","status":"LOCKED","hold_claims":["CLM-004"],"locked_at":"…"},
 "sources":[{"source_id":"SRC-01","kind":"USER_PROVIDED|POSTER|CAPTION|SCRIPT|AUDIO|WEB","ref":"berkas atau URL","accessed":true,"accessed_at":"…","authority":"jenis otoritas","date":"…","applicability":"populasi/konteks"}],
 "claims":[{"claim_id":"CLM-001","text_literal":"kutipan literal sumber","source_refs":["SRC-01"],
   "claim_type":"FACT|STATISTIC|RECOMMENDATION|CAUSAL|ASSOCIATION|SYMPTOM|DOSAGE|OTHER",
   "status":"BELUM_DIVERIFIKASI","evidence_refs":[],"verification_note":"apa diperiksa, kapan, hasilnya",
   "safe_wording":"…","allowed_in_screenplay":false,"restrictions":[],"visual_restrictions":[]}]}
```
**`06_storyboard/scenes.json`** → `{"scenes":[Scene Record]}`. Scene Record (§8.4): `project_id, scene_id, scene_order, story_beat, source_fact_refs, claim_refs, start_seconds, end_seconds, frame_start, frame_end, shot_id, visual_description, character_ids, environment_id, prop_ids, reference_ids, motion_ref_ids, overlay_ids, audio_cue_ids, subtitle_ids, continuity_in, continuity_out, guide_versions, transition, status`. Timing di sini berstatus PLANNED; setelah manifest dikompilasi, `package` memeriksa kesamaannya dengan `manifest.scene_timing` (satu sumber kebenaran: manifest).

**`08_prompts/still_reference/references.json`** → `{"references":[Reference Prompt Record]}` (§8.3): `reference_id, reference_type, project_id, scene_id, prompt, negative_constraints, aspect_ratio, target_dimensions, character_ids, environment_id, prop_ids, guide_ids, lock_versions, source_fact_refs, allowed_variations, status` + blok `asset:{file_present,file_path,sha256}`. `status` = lifecycle **prompt**; keberadaan berkas hanya di `asset` (jangan dicampur).

**`05_visual/mcg.json`** (Master Continuity Guide = indeks, bukan penulis ulang guide)
```json
{"mcg_version":"v1","depth_profile":"LITE","locks":{"STYLE_LOCK":"v1","CONTINUITY_LOCK":"v1"},
 "canonical_ids":{"characters":[{"id":"CHR-01","version":"v1","guide":"05_visual/visual_style_guide.md#CHR-01"}],"environments":[],"props":[],"styles":[{"id":"STY-01","version":"v1"}]},
 "guides":{"MVSG":{"owner":"S05","path":"05_visual/visual_style_guide.md","version":"v1"}},
 "scene_continuity":[{"scene_id":"SC-01","in":"…","out":"…","guide_versions":{"MVSG":"v1"}}],
 "change_log":[{"at":"…","id":"CHR-01","from":"v1","to":"v2","impact":["06","08"],"reason":"…"}]}
```
**`12_qa/defects.json`** → `{"defects":[{"id":"DEF-001","severity":"P0|P1|P2|P3","evidence":"…","affected_ids":["SC-03"],"owner":"S06","correction":"…","retest":"T-012","status":"OPEN|FIXED_PENDING_RETEST|CLOSED|VERIFIED_CLOSED|WONTFIX_APPROVED"}]}`.
**`12_qa/qa_matrix.json`** → baris: `TEST_ID, REQUIREMENT, EXPECTED, OBSERVED, EVIDENCE, STATUS, DEFECT_ID` (STATUS ∈ PASS, FAIL, PARTIAL, NOT_VERIFIED, NOT_RUN, NOT_APPLICABLE).

## 4. Manifest renderer-neutral (§8.5)
Kunci wajib: `schema_version, project, scene_sequence, scene_timing, reference_assets, motion_references, overlay_assets, audio_assets, subtitle_cues, layer_order, transitions, renderer_settings, capability_status, asset_paths, rights_status, open_items`. Kontrak lengkap (tipe, enum, null, referensi silang) ada di `manifest.schema.json`; contoh di `manifest.example.json`. **Timing hanya di `scene_timing`** (frames kanonis); catatan scene tidak boleh memuat timing. Klaim "tervalidasi mesin" hanya sah setelah `promkes_validate.py manifest` benar-benar dijalankan dan hasilnya dicatat.
