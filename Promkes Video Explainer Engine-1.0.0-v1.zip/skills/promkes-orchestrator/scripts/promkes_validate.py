#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""promkes_validate.py - manifest, timing and package-integrity validator for the Promkes plugin.

Python 3.8+, standard library only, no network. It performs STRUCTURAL and ARITHMETIC checks
(schema subset, cross-references, frame math, evidence rules). It does NOT judge content quality,
health accuracy, visual fidelity or whether a renderer will accept the manifest.

Subcommands
  manifest <manifest.json> [--schema S] [--root PROJECT_DIR] [--claims REGISTRY.json] [--json-out F]
  frames --fps N --durations a,b,c [--json]
  package [--dir PROJECT_DIR] [--json-out F]
Exit code: 0 = no FAIL, 1 = at least one FAIL, 2 = usage / IO error.
"""
import argparse
import hashlib
import json
import os
import re
import sys
from decimal import Decimal, ROUND_HALF_UP

VALIDATOR_VERSION = "1.0.0"
CAP_KEYS = ("image_file_access", "visual_analysis", "audio_decode", "metadata", "asr", "diarization",
            "transcript_alignment", "reference_image_generation", "code_execution",
            "renderer_availability", "export", "media_inspection")
NEEDS_FILE = ("GENERATED_UNREVIEWED", "SELECTED", "APPROVED")
PRECISION_RANK = {"NONE": 0, "ESTIMATED": 1, "SEGMENT": 2, "PHRASE": 3, "WORD": 4}
MEASURED = ("WORD", "PHRASE", "SEGMENT")
SCENE_FIELDS = ("project_id", "scene_id", "scene_order", "story_beat", "source_fact_refs", "claim_refs",
                "start_seconds", "end_seconds", "frame_start", "frame_end", "shot_id", "visual_description",
                "character_ids", "environment_id", "prop_ids", "reference_ids", "motion_ref_ids", "overlay_ids",
                "audio_cue_ids", "subtitle_ids", "continuity_in", "continuity_out", "guide_versions",
                "transition", "status")
REF_FIELDS = ("reference_id", "reference_type", "project_id", "scene_id", "prompt", "negative_constraints",
              "aspect_ratio", "target_dimensions", "character_ids", "environment_id", "prop_ids", "guide_ids",
              "lock_versions", "source_fact_refs", "allowed_variations", "status")
RENDER_REQUIRED = ("opens", "metadata", "duration", "streams", "visual_inspection", "audio_inspection",
                   "av_sync", "critical_blockers_resolved")


def die(msg, code=2):
    sys.stderr.write("ERROR: %s\n" % msg)
    sys.exit(code)


def load_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError) as e:
        die("cannot read JSON %s: %s" % (path, e))


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def to_frames(seconds, fps):
    """Canonical policy: frame = round_half_up(seconds * fps). Decimal avoids float drift."""
    return int((Decimal(str(seconds)) * Decimal(str(fps))).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def default_schema_path():
    here = os.path.dirname(os.path.abspath(__file__))
    for c in (os.path.join(here, "manifest.schema.json"), os.path.join(here, "..", "references", "manifest.schema.json")):
        if os.path.isfile(c):
            return c
    die("manifest.schema.json not found next to the script or in ../references; pass --schema")


# ----------------------------------------------------------------------------- JSON-Schema subset
def _type_ok(v, t):
    if t == "null":
        return v is None
    if t == "boolean":
        return isinstance(v, bool)
    if t == "integer":
        return (isinstance(v, int) and not isinstance(v, bool)) or (isinstance(v, float) and v.is_integer())
    if t == "number":
        return isinstance(v, (int, float)) and not isinstance(v, bool)
    if t == "string":
        return isinstance(v, str)
    if t == "array":
        return isinstance(v, list)
    if t == "object":
        return isinstance(v, dict)
    return False


def check_schema(value, schema, root, path, errs):
    """Supports: $ref(#/...), type, const, enum, required, properties, additionalProperties(bool|schema),
    items, minItems, minLength, pattern, minimum, maximum, exclusiveMinimum. Unknown keywords are ignored."""
    if "$ref" in schema:
        node = root
        for part in schema["$ref"][2:].split("/"):
            node = node[part]
        return check_schema(value, node, root, path, errs)
    t = schema.get("type")
    if t is not None:
        types = t if isinstance(t, list) else [t]
        if not any(_type_ok(value, x) for x in types):
            errs.append((path, "TYPE", "expected %s, got %s" % ("|".join(types), type(value).__name__)))
            return
    if "const" in schema and value != schema["const"]:
        errs.append((path, "CONST", "must equal %r, got %r" % (schema["const"], value)))
    if "enum" in schema and value not in schema["enum"]:
        errs.append((path, "ENUM", "%r not in %s" % (value, schema["enum"])))
    if isinstance(value, str):
        if "minLength" in schema and len(value) < schema["minLength"]:
            errs.append((path, "MINLENGTH", "string shorter than %d" % schema["minLength"]))
        if "pattern" in schema and not re.search(schema["pattern"], value):
            errs.append((path, "PATTERN", "%r does not match %s" % (value, schema["pattern"])))
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if "minimum" in schema and value < schema["minimum"]:
            errs.append((path, "MINIMUM", "%r < %r" % (value, schema["minimum"])))
        if "maximum" in schema and value > schema["maximum"]:
            errs.append((path, "MAXIMUM", "%r > %r" % (value, schema["maximum"])))
        if "exclusiveMinimum" in schema and value <= schema["exclusiveMinimum"]:
            errs.append((path, "EXCLMIN", "%r must be > %r" % (value, schema["exclusiveMinimum"])))
    if isinstance(value, list):
        if "minItems" in schema and len(value) < schema["minItems"]:
            errs.append((path, "MINITEMS", "needs at least %d item(s)" % schema["minItems"]))
        if "items" in schema:
            for i, x in enumerate(value):
                check_schema(x, schema["items"], root, "%s[%d]" % (path, i), errs)
    if isinstance(value, dict):
        for k in schema.get("required", []):
            if k not in value:
                errs.append(("%s.%s" % (path, k), "REQUIRED", "missing required field"))
        props = schema.get("properties", {})
        for k, v in value.items():
            if k in props:
                check_schema(v, props[k], root, "%s.%s" % (path, k), errs)
            else:
                ap = schema.get("additionalProperties", True)
                if ap is False:
                    errs.append(("%s.%s" % (path, k), "UNKNOWN_FIELD", "not allowed by schema"))
                elif isinstance(ap, dict):
                    check_schema(v, ap, root, "%s.%s" % (path, k), errs)


# ----------------------------------------------------------------------------- findings
class Findings(list):
    def add(self, sev, code, path, msg):
        self.append({"severity": sev, "code": code, "path": path, "message": msg})

    def fail(self, code, path, msg):
        self.add("FAIL", code, path, msg)

    def warn(self, code, path, msg):
        self.add("WARN", code, path, msg)

    def counts(self):
        return (len([f for f in self if f["severity"] == "FAIL"]), len([f for f in self if f["severity"] == "WARN"]))


def dup_ids(items, key):
    seen, dups = set(), set()
    for x in items:
        k = x.get(key)
        if k in seen:
            dups.add(k)
        seen.add(k)
    return sorted(dups)


def check_timeline(rows, fps, total_frames, F, where):
    """rows: dicts with scene_id/start_seconds/end_seconds/frame_start/frame_end in scene order."""
    for r in rows:
        p = "%s[%s]" % (where, r.get("scene_id"))
        if r["end_seconds"] <= r["start_seconds"]:
            F.fail("SECONDS_ORDER", p, "end_seconds must be > start_seconds")
        if r["frame_end"] <= r["frame_start"]:
            F.fail("FRAME_ORDER", p, "frame_end must be > frame_start (half-open range)")
        es, ee = to_frames(r["start_seconds"], fps), to_frames(r["end_seconds"], fps)
        if r["frame_start"] != es:
            F.fail("FRAME_START_MISMATCH", p, "frame_start=%d but round_half_up(%s*%s)=%d" % (r["frame_start"], r["start_seconds"], fps, es))
        if r["frame_end"] != ee:
            F.fail("FRAME_END_MISMATCH", p, "frame_end=%d but round_half_up(%s*%s)=%d" % (r["frame_end"], r["end_seconds"], fps, ee))
    if rows:
        if rows[0]["frame_start"] != 0:
            F.fail("TIMELINE_START", where, "first scene must start at frame 0, got %d" % rows[0]["frame_start"])
        for a, b in zip(rows, rows[1:]):
            if b["frame_start"] != a["frame_end"]:
                F.fail("TIMELINE_GAP_OR_OVERLAP", where, "%s ends at %d but %s starts at %d" % (a["scene_id"], a["frame_end"], b["scene_id"], b["frame_start"]))
        if total_frames is not None and rows[-1]["frame_end"] != total_frames:
            F.fail("TOTAL_FRAMES_MISMATCH", where, "last frame_end=%d but total_frames=%d" % (rows[-1]["frame_end"], total_frames))


# ----------------------------------------------------------------------------- manifest checks
def check_manifest(m, schema, root_dir=None, claims=None):
    F = Findings()
    errs = []
    check_schema(m, schema, schema, "$", errs)
    for p, c, msg in errs:
        F.fail("SCHEMA_" + c, p, msg)
    if errs:
        F.warn("CROSS_CHECKS_SKIPPED", "$", "schema errors present; cross-reference and timing checks were not run")
        return F
    P = m["project"]
    fps = P["fps"]
    total = P["total_frames"]
    scenes, timing = m["scene_sequence"], m["scene_timing"]
    sids = [s["scene_id"] for s in scenes]
    for d in dup_ids(scenes, "scene_id"):
        F.fail("DUP_SCENE_ID", "$.scene_sequence", d)
    if sorted(s["scene_order"] for s in scenes) != list(range(1, len(scenes) + 1)):
        F.fail("SCENE_ORDER_GAP", "$.scene_sequence", "scene_order must be 1..N without gaps or duplicates")
    for d in dup_ids(timing, "scene_id"):
        F.fail("DUP_TIMING", "$.scene_timing", d)
    tmap = {t["scene_id"]: t for t in timing}
    for x in sids:
        if x not in tmap:
            F.fail("TIMING_MISSING", "$.scene_timing", "no timing entry for %s" % x)
    for x in tmap:
        if x not in sids:
            F.fail("TIMING_ORPHAN", "$.scene_timing", "%s has timing but no scene" % x)
    ordered = [tmap[s["scene_id"]] for s in sorted(scenes, key=lambda s: s["scene_order"]) if s["scene_id"] in tmap]
    check_timeline(ordered, fps, total, F, "$.scene_timing")
    if total != to_frames(P["duration_seconds"], fps):
        F.fail("DURATION_FRAMES_MISMATCH", "$.project", "total_frames=%d but round_half_up(duration_seconds*fps)=%d" % (total, to_frames(P["duration_seconds"], fps)))
    aw, ah = (int(x) for x in P["aspect_ratio"].split(":"))
    if ah == 0 or P["width"] * ah != P["height"] * aw:
        F.fail("ASPECT_RESOLUTION_MISMATCH", "$.project", "%dx%d is not %s" % (P["width"], P["height"], P["aspect_ratio"]))

    coll = {"reference_assets": "reference_id", "motion_references": "motion_ref_id", "overlay_assets": "overlay_id",
            "audio_assets": "audio_id", "subtitle_cues": "subtitle_id", "transitions": "transition_id",
            "layer_order": "layer_id", "open_items": "item_id"}
    idx = {}
    for name, key in coll.items():
        for d in dup_ids(m[name], key):
            F.fail("DUP_ID", "$.%s" % name, "duplicate %s %s" % (key, d))
        idx[name] = {x[key] for x in m[name]}
    link = (("reference_ids", "reference_assets"), ("motion_ref_ids", "motion_references"), ("overlay_ids", "overlay_assets"),
            ("audio_cue_ids", "audio_assets"), ("subtitle_ids", "subtitle_cues"))
    for s in scenes:
        p = "$.scene_sequence[%s]" % s["scene_id"]
        for field, name in link:
            for x in s[field]:
                if x not in idx[name]:
                    F.fail("DANGLING_REF", "%s.%s" % (p, field), "%s is not defined in %s" % (x, name))
        if s["transition"] is not None and s["transition"] not in idx["transitions"]:
            F.fail("DANGLING_REF", "%s.transition" % p, "%s is not defined in transitions" % s["transition"])
        if s["has_factual_content"] and not s["claim_refs"]:
            F.fail("FACT_WITHOUT_CLAIM", p, "has_factual_content=true but claim_refs is empty")
    for name, key in (("reference_assets", "reference_id"), ("motion_references", "motion_ref_id"), ("overlay_assets", "overlay_id"),
                      ("audio_assets", "audio_id"), ("subtitle_cues", "subtitle_id")):
        for x in m[name]:
            sc = x.get("scene_id")
            if sc is not None and sc not in sids:
                F.fail("DANGLING_SCENE", "$.%s[%s]" % (name, x[key]), "scene_id %s does not exist" % sc)

    checked_files = False
    for r in m["reference_assets"]:
        p = "$.reference_assets[%s]" % r["reference_id"]
        if r["lifecycle"] in NEEDS_FILE and not (r["file_present"] and r["file_path"]):
            F.fail("LIFECYCLE_WITHOUT_FILE", p, "lifecycle %s requires file_present=true and file_path (prompt status != file status)" % r["lifecycle"])
        if r["file_present"] and not r["file_path"]:
            F.fail("FILE_PRESENT_NO_PATH", p, "file_present=true but file_path is null")
        if r["file_present"] and r["file_path"] and root_dir:
            checked_files = True
            full = os.path.join(root_dir, r["file_path"])
            if not os.path.isfile(full):
                F.fail("FILE_NOT_FOUND", p, "%s does not exist under --root" % r["file_path"])
            elif r["sha256"] and sha256_file(full) != r["sha256"]:
                F.fail("FILE_HASH_MISMATCH", p, "sha256 differs from file on disk")
    for au in m["audio_assets"]:
        p = "$.audio_assets[%s]" % au["audio_id"]
        if au["file_present"] and not au["file_path"]:
            F.fail("FILE_PRESENT_NO_PATH", p, "file_present=true but file_path is null")
        if au["file_present"] and au["file_path"] and root_dir:
            checked_files = True
            if not os.path.isfile(os.path.join(root_dir, au["file_path"])):
                F.fail("FILE_NOT_FOUND", p, "%s does not exist under --root" % au["file_path"])
    if not root_dir and any(r["file_present"] for r in m["reference_assets"] + m["audio_assets"]):
        F.warn("FILE_EXISTENCE_NOT_CHECKED", "$", "file_present=true entries exist but --root was not given; existence/hash not verified")

    def in_global(obj, a, b, p):
        if not (0 <= obj[a] < obj[b] <= total):
            F.fail("FRAME_RANGE_INVALID", p, "need 0 <= %s < %s <= total_frames(%d); got %d..%d" % (a, b, total, obj[a], obj[b]))
            return False
        return True
    for name, key, ca, cb in (("overlay_assets", "overlay_id", "start_frame", "end_frame"), ("subtitle_cues", "subtitle_id", "start_frame", "end_frame"),
                              ("audio_assets", "audio_id", "start_frame", "end_frame")):
        for x in m[name]:
            p = "$.%s[%s]" % (name, x[key])
            if in_global(x, ca, cb, p) and x.get("scene_id") in tmap:
                t = tmap[x["scene_id"]]
                if x[ca] < t["frame_start"] or x[cb] > t["frame_end"]:
                    F.warn("CROSSES_SCENE_BOUNDARY", p, "frames %d..%d fall outside %s (%d..%d); confirm this is intentional" % (x[ca], x[cb], x["scene_id"], t["frame_start"], t["frame_end"]))
    for o in m["overlay_assets"]:
        if o["is_factual"] and not o["claim_refs"]:
            F.fail("FACT_WITHOUT_CLAIM", "$.overlay_assets[%s]" % o["overlay_id"], "is_factual=true but claim_refs is empty")
    amap = {a["audio_id"]: a for a in m["audio_assets"]}
    notexp = []
    for c in m["subtitle_cues"]:
        p = "$.subtitle_cues[%s]" % c["subtitle_id"]
        if c["timing_precision"] not in MEASURED:
            notexp.append(c["subtitle_id"])
        if c["audio_id"] is not None:
            a = amap.get(c["audio_id"])
            if a is None:
                F.fail("DANGLING_REF", p, "audio_id %s is not defined" % c["audio_id"])
            elif PRECISION_RANK[c["timing_precision"]] > PRECISION_RANK[a["timing_precision"]]:
                F.fail("SUBTITLE_PRECISION_EXCEEDS_AUDIO", p, "cue claims %s but audio %s only supports %s" % (c["timing_precision"], a["audio_id"], a["timing_precision"]))
    if notexp:
        F.warn("SUBTITLE_TIMING_NOT_EXPORTABLE", "$.subtitle_cues", "%d cue(s) have ESTIMATED/NONE timing; SRT/VTT export is not permitted until timing is measured: %s" % (len(notexp), ", ".join(notexp)))
    for a in m["audio_assets"]:
        if a["rights_status"] in ("UNKNOWN", "NOT_LICENSED"):
            F.warn("RIGHTS_UNRESOLVED", "$.audio_assets[%s]" % a["audio_id"], "rights_status=%s blocks public release (never assume a licence)" % a["rights_status"])
        mapped = m["rights_status"].get(a["audio_id"])
        if mapped is not None and mapped != a["rights_status"]:
            F.warn("RIGHTS_INCONSISTENT", "$.rights_status[%s]" % a["audio_id"], "map says %s, audio asset says %s" % (mapped, a["rights_status"]))
    rs, caps = m["renderer_settings"], m["capability_status"]
    if rs["render_readiness"] in ("NATIVE", "PROGRAMMATIC"):
        if rs["adapter_status"] != "VERIFIED":
            F.fail("READINESS_WITHOUT_ADAPTER", "$.renderer_settings", "render_readiness=%s requires adapter_status=VERIFIED (found %s)" % (rs["render_readiness"], rs["adapter_status"]))
        if caps.get("renderer_availability", {}).get("status") != "VERIFIED":
            F.fail("READINESS_WITHOUT_CAPABILITY", "$.capability_status", "render_readiness=%s requires renderer_availability=VERIFIED" % rs["render_readiness"])
    miss = [k for k in CAP_KEYS if k not in caps]
    if miss:
        F.warn("CAPABILITY_KEYS_MISSING", "$.capability_status", "not recorded: %s" % ", ".join(miss))
    for it in m["open_items"]:
        if it["status"] == "OPEN" and it["severity"] in ("P0", "P1"):
            F.warn("OPEN_HIGH_SEVERITY", "$.open_items[%s]" % it["item_id"], "%s item is still open" % it["severity"])
    if claims is not None:
        cm = {c["claim_id"]: c for c in claims.get("claims", [])}
        used = set()
        for s in scenes:
            used.update(s["claim_refs"])
        for o in m["overlay_assets"]:
            used.update(o["claim_refs"])
        for cid in sorted(used):
            c = cm.get(cid)
            if c is None:
                F.fail("CLAIM_UNKNOWN", "$", "%s is referenced but absent from the Health Truth Registry" % cid)
            elif c.get("status") in ("CONTRADICTED", "UNKNOWN") or not c.get("allowed_in_screenplay", False):
                F.fail("CLAIM_NOT_ALLOWED", "$", "%s (status=%s, allowed_in_screenplay=%s) must not appear in screenplay/visuals" % (cid, c.get("status"), c.get("allowed_in_screenplay")))
    elif any(s["claim_refs"] for s in scenes):
        F.warn("CLAIMS_NOT_CROSS_CHECKED", "$", "claim_refs present but no --claims registry given; claim status not verified")
    return F


def print_findings(F, title):
    for f in F:
        print("[%s] %s %s -- %s" % (f["severity"], f["code"], f["path"], f["message"]))
    nf, nw = F.counts()
    print("%s: %d FAIL, %d WARN -> %s" % (title, nf, nw, "FAIL" if nf else "PASS (structural/arithmetic checks only; content quality is not judged)"))


def write_json_out(path, payload):
    if path:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
            f.write("\n")


def cmd_manifest(a):
    schema = load_json(a.schema or default_schema_path())
    m = load_json(a.manifest)
    claims = load_json(a.claims) if a.claims else None
    F = check_manifest(m, schema, a.root, claims)
    print_findings(F, "manifest %s" % a.manifest)
    write_json_out(a.json_out, {"validator_version": VALIDATOR_VERSION, "target": a.manifest, "findings": F, "fail": F.counts()[0], "warn": F.counts()[1]})
    return 1 if F.counts()[0] else 0


def cmd_frames(a):
    try:
        durs = [Decimal(x.strip()) for x in a.durations.split(",") if x.strip()]
    except Exception:  # noqa: BLE001
        die("--durations must be comma-separated numbers (seconds)")
    if not durs or any(d <= 0 for d in durs):
        die("durations must be positive")
    rows, cum = [], Decimal(0)
    for i, d in enumerate(durs, 1):
        s, e = cum, cum + d
        rows.append({"scene_id": "SC-%02d" % i, "start_seconds": float(s), "end_seconds": float(e),
                     "frame_start": to_frames(s, a.fps), "frame_end": to_frames(e, a.fps), "timing_basis": "PLANNED"})
        cum = e
    if a.json:
        print(json.dumps(rows, indent=2))
    else:
        print("fps=%s policy=round_half_up on CUMULATIVE boundaries (keeps scenes contiguous; total is exact)" % a.fps)
        print("scene   start_s    end_s  frame_start  frame_end  frames")
        for r in rows:
            print("%-6s %8.3f %8.3f %12d %10d %7d" % (r["scene_id"], r["start_seconds"], r["end_seconds"], r["frame_start"], r["frame_end"], r["frame_end"] - r["frame_start"]))
        print("total_seconds=%s total_frames=%d" % (cum, rows[-1]["frame_end"]))
    return 0


def cmd_package(a):
    pdir = os.path.abspath(a.dir or ".")
    sp = os.path.join(pdir, "project_state.json")
    if not os.path.isfile(sp):
        die("no project_state.json in %s (use --dir)" % pdir)
    st = load_json(sp)
    F = Findings()
    phases = st["phases"]
    SAT = ("DONE", "SKIPPED")
    for ph, s in sorted(phases.items()):
        if s["status"] == "DONE":
            for d in s.get("depends_on", []):
                if phases[d]["status"] not in SAT:
                    F.fail("STATE_DEP_VIOLATION", "phase %s" % ph, "DONE but dependency %s is %s" % (d, phases[d]["status"]))
            for art in s.get("artifacts", []):
                full = os.path.join(pdir, art["path"])
                if not os.path.isfile(full):
                    F.fail("ARTIFACT_MISSING", "phase %s" % ph, art["path"])
                elif sha256_file(full) != art["sha256"]:
                    F.warn("ARTIFACT_CHANGED", "phase %s" % ph, "%s changed since completion; run `touch %s` and revalidate" % (art["path"], ph))
        elif s["status"] == "STALE":
            F.warn("STALE_PHASE", "phase %s" % ph, s.get("stale_reason", "stale"))
        elif s["status"] in ("HOLD", "BLOCKED"):
            F.warn("PHASE_%s" % s["status"], "phase %s" % ph, s.get("hold_reason", ""))
    fpsv = st["variables"].get("FRAME_RATE", {}).get("value")
    fps = fpsv if isinstance(fpsv, (int, float)) and fpsv > 0 else None

    def opt(*parts):
        p = os.path.join(pdir, *parts)
        return load_json(p) if os.path.isfile(p) else None
    registry = opt("02_health", "health_truth_registry.json")
    scenes_doc = opt("06_storyboard", "scenes.json")
    refs_doc = opt("08_prompts", "still_reference", "references.json")
    defects_doc = opt("12_qa", "defects.json")
    manifest = opt("10_renderer", "manifest.json")
    schema = load_json(default_schema_path())
    lifecycle = set(schema["$defs"]["lifecycle"]["enum"])
    claim_map = {c["claim_id"]: c for c in (registry or {}).get("claims", [])}
    if registry is not None:
        for c in registry.get("claims", []):
            if c.get("status") not in ("VERIFIED", "PARTIALLY_SUPPORTED", "MIXED_OR_CONTESTED", "BELUM_DIVERIFIKASI", "CONTRADICTED", "UNKNOWN"):
                F.fail("CLAIM_STATUS_INVALID", "claims[%s]" % c.get("claim_id"), "status %r is not one of the six allowed values" % c.get("status"))
            if c.get("status") == "VERIFIED" and not c.get("evidence_refs"):
                F.fail("VERIFIED_WITHOUT_EVIDENCE", "claims[%s]" % c.get("claim_id"), "VERIFIED requires evidence_refs to sources that were actually accessed")
    ref_ids = {r.get("reference_id") for r in (refs_doc or {}).get("references", [])}
    if scenes_doc is not None:
        sc = scenes_doc.get("scenes", [])
        for s in sc:
            p = "scenes[%s]" % s.get("scene_id")
            miss = [k for k in SCENE_FIELDS if k not in s]
            if miss:
                F.fail("SCENE_FIELD_MISSING", p, "missing: %s" % ", ".join(miss))
                continue
            for cid in s["claim_refs"]:
                c = claim_map.get(cid)
                if registry is None:
                    F.warn("NO_CLAIM_REGISTRY", p, "claim_refs present but 02_health/health_truth_registry.json is absent")
                    break
                if c is None:
                    F.fail("CLAIM_UNKNOWN", p, "%s not in registry" % cid)
                elif not c.get("allowed_in_screenplay", False) or c.get("status") in ("CONTRADICTED", "UNKNOWN"):
                    F.fail("CLAIM_NOT_ALLOWED", p, "%s (status=%s) is not allowed in screenplay/visuals" % (cid, c.get("status")))
            if refs_doc is not None:
                for rid in s["reference_ids"]:
                    if rid not in ref_ids:
                        F.fail("DANGLING_REF", p, "reference %s not in references.json" % rid)
        if fps:
            rows = [s for s in sorted(sc, key=lambda s: s.get("scene_order", 0)) if all(k in s for k in ("start_seconds", "end_seconds", "frame_start", "frame_end"))]
            check_timeline(rows, fps, None, F, "scenes.json")
        if manifest is not None:
            mt = {t["scene_id"]: t for t in manifest.get("scene_timing", [])}
            for s in sc:
                t = mt.get(s.get("scene_id"))
                if t and (t["frame_start"], t["frame_end"]) != (s.get("frame_start"), s.get("frame_end")):
                    F.fail("SCENES_VS_MANIFEST_TIMING", "scenes[%s]" % s["scene_id"], "scenes.json %s..%s vs manifest %s..%s (one source of truth: reconcile)" % (s.get("frame_start"), s.get("frame_end"), t["frame_start"], t["frame_end"]))
    if refs_doc is not None:
        for r in refs_doc.get("references", []):
            p = "references[%s]" % r.get("reference_id")
            miss = [k for k in REF_FIELDS if k not in r]
            if miss:
                F.fail("REF_FIELD_MISSING", p, "missing: %s" % ", ".join(miss))
                continue
            if not str(r["prompt"]).strip():
                F.fail("REF_PROMPT_EMPTY", p, "prompt is empty")
            if not r["negative_constraints"]:
                F.fail("REF_NEGATIVE_MISSING", p, "negative_constraints must not be empty (material constraints may not be dropped)")
            if r["status"] not in lifecycle:
                F.fail("REF_STATUS_INVALID", p, "status %r not in lifecycle enum" % r["status"])
    if manifest is not None:
        MF = check_manifest(manifest, schema, pdir, registry)
        for f in MF:
            F.add(f["severity"], "MANIFEST_" + f["code"], f["path"], f["message"])
    elif phases.get("10", {}).get("status") == "DONE":
        F.fail("MANIFEST_ABSENT", "10_renderer/manifest.json", "phase 10 is DONE but the manifest file is missing")
    open_p0 = open_p1 = 0
    if defects_doc is not None:
        for d in defects_doc.get("defects", []):
            if d.get("status") not in ("CLOSED", "VERIFIED_CLOSED", "WONTFIX_APPROVED"):
                if d.get("severity") == "P0":
                    open_p0 += 1
                elif d.get("severity") == "P1":
                    open_p1 += 1
        if open_p0:
            F.fail("OPEN_P0_DEFECT", "12_qa/defects.json", "%d open P0 defect(s): stop and escalate" % open_p0)
        if open_p1:
            F.warn("OPEN_P1_DEFECT", "12_qa/defects.json", "%d open P1 defect(s): HOLD affected components" % open_p1)

    def sat(p):
        return phases.get(p, {}).get("status") in SAT
    nf = F.counts()[0]
    any_blocked = any(s["status"] == "BLOCKED" for s in phases.values()) or open_p0
    blueprint = all(sat(p) for p in ("01", "02", "03", "04", "05", "06", "07"))
    ref_ready = blueprint and all(sat(p) for p in ("08", "10", "12")) and nf == 0
    rs = (manifest or {}).get("renderer_settings", {})
    caps = (manifest or {}).get("capability_status", {})
    render_ready = ref_ready and rs.get("adapter_status") == "VERIFIED" and rs.get("render_readiness") in ("NATIVE", "PROGRAMMATIC") \
        and caps.get("renderer_availability", {}).get("status") == "VERIFIED"
    ceiling = "BLOCKED" if any_blocked else ("BLUEPRINT_ONLY" if blueprint else "INCOMPLETE (blueprint phases 01-07 not all satisfied)")
    if ref_ready:
        ceiling = "REFERENCE_READY"
    if render_ready:
        ceiling = "RENDER_READY"
    ev = opt("13_handoff", "render_evidence.json")
    if ev is not None and render_ready:
        fpath = os.path.join(pdir, ev.get("file_path", ""))
        if not os.path.isfile(fpath):
            F.fail("RENDER_EVIDENCE_FILE_MISSING", "13_handoff/render_evidence.json", "file_path does not exist: no rendered artifact, no RENDERED_* state")
        else:
            checks = ev.get("checks", {})
            ok = all(checks.get(k) in ("PASS", "NOT_APPLICABLE") for k in RENDER_REQUIRED)
            ceiling = "RENDERED_VERIFIED" if ok else "RENDERED_PARTIALLY_VERIFIED"
    print_findings(F, "package %s" % st["project"]["id"])
    print("Evidence-supported delivery-state ceiling: %s" % ceiling)
    print("(A ceiling, not a decision: M00 records the final state; human approval is tracked separately and is NOT implied.)")
    write_json_out(a.json_out, {"validator_version": VALIDATOR_VERSION, "project": st["project"]["id"], "findings": F, "ceiling": ceiling})
    return 1 if F.counts()[0] else 0


def main(argv=None):
    ap = argparse.ArgumentParser(prog="promkes_validate.py", description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("manifest")
    p.add_argument("manifest")
    p.add_argument("--schema")
    p.add_argument("--root")
    p.add_argument("--claims")
    p.add_argument("--json-out")
    p.set_defaults(fn=cmd_manifest)
    p = sub.add_parser("frames")
    p.add_argument("--fps", type=float, required=True)
    p.add_argument("--durations", required=True)
    p.add_argument("--json", action="store_true")
    p.set_defaults(fn=cmd_frames)
    p = sub.add_parser("package")
    p.add_argument("--dir")
    p.add_argument("--json-out")
    p.set_defaults(fn=cmd_package)
    a = ap.parse_args(argv)
    sys.exit(a.fn(a) or 0)


if __name__ == "__main__":
    main()
