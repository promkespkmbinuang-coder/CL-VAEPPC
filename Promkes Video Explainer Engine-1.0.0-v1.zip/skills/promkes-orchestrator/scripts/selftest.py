#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""selftest.py - proves the Promkes tools work in THIS environment (stdlib only, no network).

Runs validator fault-injection against the example manifest, then state / change-impact / package
checks inside a temporary folder. Exit code 1 if any test fails. Never touches real projects."""
import copy
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))


def find(name):
    for d in (HERE, os.path.join(HERE, "..", "references")):
        p = os.path.join(d, name)
        if os.path.isfile(p):
            return p
    sys.exit("selftest: cannot find %s next to the script or in ../references" % name)


def jload(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


spec = importlib.util.spec_from_file_location("pv", os.path.join(HERE, "promkes_validate.py"))
V = importlib.util.module_from_spec(spec)
spec.loader.exec_module(V)
SCHEMA, EXAMPLE = jload(find("manifest.schema.json")), jload(find("manifest.example.json"))
RES = []


def rec(name, ok, detail=""):
    RES.append(bool(ok))
    print("%-5s %-50s %s" % ("PASS" if ok else "FAIL", name, detail))


def codes(m, claims=None):
    F = V.check_manifest(m, SCHEMA, None, claims)
    return ({f["code"] for f in F if f["severity"] == "FAIL"}, {f["code"] for f in F if f["severity"] == "WARN"})


def mut(fn):
    m = copy.deepcopy(EXAMPLE)
    fn(m)
    return m


FAULTS = [
    ("frame_start tampered", lambda m: m["scene_timing"][1].__setitem__("frame_start", 91), "FRAME_START_MISMATCH"),
    ("dangling reference id", lambda m: m["scene_sequence"][0]["reference_ids"].append("REF-KEY-99"), "DANGLING_REF"),
    ("APPROVED lifecycle without file", lambda m: m["reference_assets"][1].__setitem__("lifecycle", "APPROVED"), "LIFECYCLE_WITHOUT_FILE"),
    ("readiness claimed without adapter check", lambda m: m["renderer_settings"].__setitem__("render_readiness", "PROGRAMMATIC"), "READINESS_WITHOUT_ADAPTER"),
    ("factual scene without claim", lambda m: m["scene_sequence"][1].__setitem__("claim_refs", []), "FACT_WITHOUT_CLAIM"),
    ("gap in timeline", lambda m: m["scene_timing"][1].update(start_seconds=3.5, frame_start=105), "TIMELINE_GAP_OR_OVERLAP"),
    ("timing duplicated inside scene record", lambda m: m["scene_sequence"][0].__setitem__("start_seconds", 0), "SCHEMA_UNKNOWN_FIELD"),
    ("subtitle precision above audio precision", lambda m: m["subtitle_cues"][0].__setitem__("timing_precision", "WORD"), "SUBTITLE_PRECISION_EXCEEDS_AUDIO"),
    ("total_frames wrong", lambda m: m["project"].__setitem__("total_frames", 361), "TOTAL_FRAMES_MISMATCH"),
    ("enum violation", lambda m: m["project"].__setitem__("route", "FOO"), "SCHEMA_ENUM"),
    ("factual overlay without claim", lambda m: m["overlay_assets"][0].__setitem__("claim_refs", []), "FACT_WITHOUT_CLAIM"),
    ("aspect/resolution mismatch", lambda m: m["project"].__setitem__("height", 1900), "ASPECT_RESOLUTION_MISMATCH"),
    ("duplicate scene id", lambda m: m["scene_sequence"][2].__setitem__("scene_id", "SC-02"), "DUP_SCENE_ID"),
    ("frame outside timeline", lambda m: m["subtitle_cues"][2].__setitem__("end_frame", 999), "FRAME_RANGE_INVALID"),
]


def run_validator_tests():
    fails, warns = codes(EXAMPLE)
    rec("example manifest has 0 FAIL", not fails, "FAIL=%s" % sorted(fails))
    rec("example manifest raises expected WARNs", {"SUBTITLE_TIMING_NOT_EXPORTABLE", "RIGHTS_UNRESOLVED"} <= warns)
    for name, fn, want in FAULTS:
        f, _ = codes(mut(fn))
        rec("fault detected: " + name, want in f, "" if want in f else "got=%s" % sorted(f))
    bad = {"claims": [{"claim_id": "CLM-001", "status": "CONTRADICTED", "allowed_in_screenplay": False},
                      {"claim_id": "CLM-002", "status": "VERIFIED", "allowed_in_screenplay": True}]}
    rec("fault detected: contradicted claim in use", "CLAIM_NOT_ALLOWED" in codes(EXAMPLE, bad)[0])
    rec("fault detected: unknown claim id", "CLAIM_UNKNOWN" in codes(EXAMPLE, {"claims": [bad["claims"][1]]})[0])
    rec("rounding is half-up (2.5->3, 0.05s@30fps->2)", V.to_frames(2.5, 1) == 3 and V.to_frames(0.05, 30) == 2)


def run_state_tests():
    S = os.path.join(HERE, "promkes_state.py")

    def run(*a):
        r = subprocess.run([sys.executable, S] + list(a), capture_output=True, text=True, timeout=90)
        return r.returncode, r.stdout + r.stderr
    tmp = tempfile.mkdtemp(prefix="promkes_selftest_")
    try:
        rc, out = run("init", "--title", "Selftest Proyek", "--base", tmp)
        m = re.search(r"Project created: (.+)", out)
        pdir = m.group(1).strip() if m else ""
        rec("state: init creates project + tools", rc == 0 and os.path.isfile(os.path.join(pdir, "project_state.json"))
            and os.path.isfile(os.path.join(pdir, "tools", "promkes_validate.py")))
        D = ["--dir", pdir]

        def write(rel, text):
            with open(os.path.join(pdir, rel), "w", encoding="utf-8") as f:
                f.write(text)
            return rel
        rec("state: begin refused while 00 not done", run("begin", "01", *D)[0] == 2)
        rec("state: capability probe runs", run("capabilities", *D)[0] == 0)
        rec("state: complete 00 hashes artifact", run("complete", "00", "--artifact", "00_intake/capabilities.json", *D)[0] == 0)
        for ph, rel in (("01", "01_source/source_dossier.md"), ("02", "02_health/fact_lock.md"), ("03", "03_campaign/creative_brief.md")):
            run("begin", ph, *D)
            write(rel, "v1 " + ph)
            rc, _ = run("complete", ph, "--artifact", rel, *D)
        rec("state: sequential completion 01-03", rc == 0)
        write("01_source/source_dossier.md", "v1 typo fixed")
        rec("no-propagate refused without a reason", run("complete", "01", "--artifact", "01_source/source_dossier.md", "--no-propagate", *D)[0] == 2)
        rc, _ = run("complete", "01", "--artifact", "01_source/source_dossier.md", "--no-propagate", "--note", "typo only", *D)
        st = jload(os.path.join(pdir, "project_state.json"))
        rec("no-propagate keeps 02+03 DONE (logged exception)", rc == 0 and st["phases"]["02"]["status"] == "DONE" and st["phases"]["03"]["status"] == "DONE")
        write("01_source/source_dossier.md", "v2 changed")
        rc, out = run("complete", "01", "--artifact", "01_source/source_dossier.md", *D)
        st = jload(os.path.join(pdir, "project_state.json"))
        rec("change impact: re-completing 01 stales 02+03", st["phases"]["02"]["status"] == "STALE" and st["phases"]["03"]["status"] == "STALE"
            and st["phases"]["00"]["status"] == "DONE", "downstream=%s" % [st["phases"][p]["status"] for p in ("02", "03")])
        rec("gating: begin 04 refused while 02/03 stale", run("begin", "04", *D)[0] == 2)
        write("00_intake/capabilities.json", "{}")
        rc, out = run("status", *D)
        rec("integrity: status detects changed artifact", rc == 1 and "CHANGED" in out)
        run("capabilities", *D)
        st = jload(os.path.join(pdir, "project_state.json"))
        rec("capability re-probe re-hashes, does not stale 01", run("status", *D)[0] == 0 and st["phases"]["01"]["status"] == "DONE")
        for ph, rel in (("02", "02_health/fact_lock.md"), ("03", "03_campaign/creative_brief.md")):
            run("complete", ph, "--artifact", rel, *D)
        run("touch", "02", "--reason", "selftest upstream change", *D)
        st = jload(os.path.join(pdir, "project_state.json"))
        rec("change impact: touch 02 stales 02+03 only", st["phases"]["02"]["status"] == "STALE" and st["phases"]["03"]["status"] == "STALE"
            and st["phases"]["01"]["status"] == "DONE")
        with open(os.path.join(pdir, "RESUME.md"), encoding="utf-8") as f:
            rtxt = f.read()
        rec("resume: RESUME.md names the next step", "## Berikutnya" in rtxt and "Fase 02" in rtxt)
        # package-level checks
        os.makedirs(os.path.join(pdir, "10_renderer"), exist_ok=True)
        shutil.copy(find("manifest.example.json"), os.path.join(pdir, "10_renderer", "manifest.json"))
        scenes = []
        for s, t in zip(EXAMPLE["scene_sequence"], EXAMPLE["scene_timing"]):
            r = {"project_id": "PRJ-EXAMPLE-0001"}
            r.update(s)
            r.update({k: t[k] for k in ("start_seconds", "end_seconds", "frame_start", "frame_end")})
            scenes.append(r)
        with open(os.path.join(pdir, "06_storyboard", "scenes.json"), "w", encoding="utf-8") as f:
            json.dump({"scenes": scenes}, f)
        with open(os.path.join(pdir, "02_health", "health_truth_registry.json"), "w", encoding="utf-8") as f:
            json.dump({"claims": [{"claim_id": "CLM-002", "status": "VERIFIED", "evidence_refs": ["SRC-01"], "allowed_in_screenplay": True}]}, f)
        P = os.path.join(HERE, "promkes_validate.py")
        r = subprocess.run([sys.executable, P, "package", "--dir", pdir], capture_output=True, text=True, timeout=60)
        rec("package: unknown claim in scenes -> FAIL", r.returncode == 1 and "CLAIM_UNKNOWN" in r.stdout)
        rec("package: ceiling stays below RENDER_READY", "ceiling: RENDER" not in r.stdout and "ceiling: REFERENCE_READY" not in r.stdout
            and "ceiling: " in r.stdout)
        r = subprocess.run([sys.executable, P, "frames", "--fps", "30", "--durations", "3,5.5,3.5"], capture_output=True, text=True, timeout=30)
        rec("frames helper: 3+5.5+3.5s @30fps = 360 frames", "total_frames=360" in r.stdout)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    run_validator_tests()
    run_state_tests()
    print("\n%d/%d tests passed" % (sum(RES), len(RES)))
    sys.exit(0 if all(RES) else 1)
