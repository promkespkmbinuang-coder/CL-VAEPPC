---
name: resume
description: Lanjutkan (resume) proyek promkes dari state di disk atau dari blok RESUME.md yang ditempel, tampilkan status, lalu jalankan fase berikutnya. Gunakan ketika pengguna mengetik /promkes:resume atau meminta melanjutkan proyek video explainer promkes setelah sesi terputus atau token habis.
---

# /promkes:resume

Argumen pengguna (abaikan bila tertulis literal `$ARGUMENTS`): $ARGUMENTS

1. **Temukan proyek**: dari argumen, atau cari `project_state.json` (folder kerja, `promkes_projects/`, berkas terunggah). Bila hanya ada teks `RESUME.md` tanpa folder proyek, minta folder atau `project_state.json`-nya; jangan merekonstruksi state dari ingatan.
2. Jalankan `status` (membandingkan hash artefak). Bila ada `CHANGED`/`MISSING`, tanyakan (satu pertanyaan) apakah perubahannya material: material → `touch`; tak material → `complete … --no-propagate --note …`.
3. Baca **hanya** `RESUME.md` dan artefak hulu yang tercantum di bagian *Berikutnya*; jangan memuat ulang seluruh proyek.
4. Argumen `status` → tampilkan status lalu berhenti. `resume-prompt` → cetak blok untuk sesi baru lalu berhenti. `phase N` → `begin N` (memaksa melewati prasyarat hanya atas permintaan eksplisit pengguna, dengan alasan tercatat).
5. Tanpa argumen lain: jalankan fase berikutnya lewat skill pemiliknya dengan loop M00 (begin → kerja → complete → gerbang → receipt). Fase berat dikerjakan per batch; bila konteks terasa berat, berhenti di batas batch dan cetak `resume-prompt`.
