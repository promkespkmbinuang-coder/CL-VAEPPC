---
name: promkes-qa-handoff
description: Fase 12 pipeline promkes (S12). QA independen lima level - paket prompt/referensi, aset referensi hasil generasi, integrasi renderer, artefak media hasil render, persetujuan manusia - dengan matriks uji, defect register (DEF-ID, severity, bukti, pemilik, retest), targeted retest, dan laporan handoff teknis. Gunakan untuk memeriksa, mengaudit, atau menyerahterimakan paket produksi video kesehatan, atau untuk menjalankan validator. English - independent QA, defect management, and technical handoff.
---

# Promkes — Independent QA (S12) & Handoff

**Independensi**: penguji bukan penulis. Uji **dari berkas di disk** (baca ulang artefak; jangan mengandalkan ingatan sesi penulisan). Bila sub-agent `promkes-qa-auditor` tersedia (Cowork / Claude Code), delegasikan pemeriksaan kepadanya dengan konteks bersih; bila tidak, kerjakan dari berkas dan nyatakan bahwa independensinya terbatas.

## Lima level penerimaan (klaim hanya level yang buktinya ada)
L1 Prompt/Reference Package · L2 Generated Reference Asset (hanya bila berkas gambar nyata ada) · L3 Renderer Integration (hanya bila adapter/runtime ada) · L4 Rendered Media Artifact (hanya bila file video/audio nyata ada) · L5 Human Approval (dicatat terpisah; bukan keputusan QA). Level tanpa bukti → NOT_RUN atau NOT_APPLICABLE, bukan PASS.

## Katalog uji — `TEST_ID | REQUIREMENT | EXPECTED | OBSERVED | EVIDENCE | STATUS | DEFECT_ID`
Source integrity · health claim integrity (tiap klaim ber-ID dan berstatus; klaim ditahan tidak terpakai; Safe Wording dipatuhi; tak ada kausalitas dari asosiasi, janji absolut, atau manipulasi rasa takut) · screenplay consistency · character identity · scene continuity (in/out cocok) · reference prompt quality (mandiri, negative constraints ada, tanpa perintah video) · motion specification · timing arithmetic · manifest integrity · code/schema validity · capability compatibility · file/render integrity bila artefak ada.

Bukti mesin dulu, lalu uji semantik manual:
```bash
python tools/promkes_validate.py package --json-out 12_qa/package_check.json
python tools/promkes_validate.py manifest 10_renderer/manifest.json --root . --claims 02_health/health_truth_registry.json
python tools/selftest.py        # membuktikan toolbox sehat di lingkungan ini
```
Status: PASS · FAIL · PARTIAL · NOT_VERIFIED · NOT_RUN · NOT_APPLICABLE; tiga yang terakhir selain NOT_APPLICABLE tidak boleh menjadi PASS. Pisahkan hasil: static package · prompt/reference · integration · target-model testing · renderer testing · artifact testing. Validator hanya memeriksa struktur dan aritmetika, **bukan** akurasi kesehatan atau mutu visual.

## Defect — `12_qa/defects.json`
DEF-ID · severity (P0 stop/eskalasi · P1 HOLD komponen · P2 fallback/disclosure · P3 koreksi lokal) · evidence · affected ID · owner (S-id) · correction · retest · status. Setelah perbaikan lakukan **targeted retest** pada ID terdampak + regresi kritis; `touch` fase pemilik agar turunannya STALE. Defect ditutup hanya setelah retest PASS.

## Pemeriksaan artefak render (hanya bila file nyata ada)
```bash
ffprobe -v error -show_format -show_streams -of json <file>
```
Cocokkan durasi, resolusi, fps dengan manifest; periksa stream video/audio; periksa visual dan audio sesuai kemampuan; sinkron A/V bila memungkinkan. Catat di `13_handoff/render_evidence.json` (`file_path`, `checks`: opens, metadata, duration, streams, visual_inspection, audio_inspection, av_sync, critical_blockers_resolved).

## Handoff — `13_handoff/final_status.md` (OUTPUT 16–17)
Ringkasan eksekutif · matriks QA · defect terbuka · batas platform · apa yang **belum** dijalankan · ceiling dari `package` · **satu** delivery state ≤ ceiling · status persetujuan manusia (terpisah). Jangan menyatakan persetujuan klinis, institusional, legal, atau publikasi tanpa bukti otorisasi manusia.

## Setelah selesai
`complete 12 --artifact 12_qa/qa_report.md --artifact 12_qa/qa_matrix.json --artifact 12_qa/defects.json`; Fase 13 dijalankan M00.
