# Adapter renderer — daftar periksa dan pemetaan konsep

## 1. Daftar periksa (isi `adapter_check.md`)
| Item | Pertanyaan | Bukti yang diterima | Status |
|---|---|---|---|
| Platform | renderer apa yang sebenarnya dipakai? | pernyataan pengguna + berkas proyek | VERIFIED / NOT_CHECKED |
| Versi | versi terpasang? | `package.json` / keluaran versi nyata | idem |
| Komponen/interface | titik masuk komposisi? | entry file proyek | idem |
| Input schema | bentuk props/konfigurasi yang diterima? | berkas schema/tipe proyek | idem |
| Dependensi | paket dan runtime yang dibutuhkan? | `capabilities --renderer-root` | idem |
| Asset path | konvensi folder aset? | struktur proyek | idem |
| Render route | perintah render yang sah? | dokumentasi versi terpasang atau skrip proyek | idem |
| Export capability | codec/format yang didukung? | proof render | idem |
VERIFIED hanya bila dibaca dari proyek atau dokumentasi versi terpasang yang nyata. Minta pengguna: `package.json`, entry file, bentuk props komposisi, struktur folder aset, perintah render yang dipakai.

## 2. Pemetaan konseptual manifest → Remotion (status: **NOT_CHECKED** terhadap versi terpasang mana pun)
Hanya konsep umum; nama impor persis, komponen audio, dan flag CLI **wajib diverifikasi** pada versi proyek sebelum dipakai.
| Manifest | Konsep Remotion | Catatan |
|---|---|---|
| project.fps / width / height / total_frames | properti komposisi (fps, width, height, durationInFrames) | durasi dalam frames |
| scene_timing[i] | `Sequence` dengan `from` = frame_start dan `durationInFrames` = frame_end − frame_start | half-open, tanpa celah |
| layer_order (z_index) | urutan penumpukan elemen dalam `AbsoluteFill` | |
| asset_path referensi/overlay | aset statis lewat mekanisme aset proyek | cek konvensi folder proyek |
| motion_references (easing, timing) | `interpolate` / `spring` berdasarkan frame lokal | terjemahkan nama easing ke fungsi; jangan menyalin kurva |
| audio_assets / subtitle_cues | komponen audio + teks dari cue (frames) | cek komponen audio versi terpasang |
| data masukan | props komposisi | manifest generik **bukan** otomatis inputProps; tulis adapter pemetaannya |
Prasyarat sebelum kode: proyek ada, dependensi terpasang, `node` tersedia. Perintah render diambil dari dokumentasi versi terpasang atau skrip proyek; mulai dengan proof render (still atau rentang frame pendek). Jangan mengarang flag.

## 3. Target lain (native AI video, FFmpeg-only, platform lain)
Isi tabel §1 dengan fakta nyata; bila tak diketahui → HANDOFF dan kode spesifik-platform NOT_CHECKED.
