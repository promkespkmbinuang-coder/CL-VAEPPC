---
name: promkes-renderer-manifest
description: Fase 10 pipeline promkes (S10). Kompilasi manifest renderer-neutral dengan satu sumber timing dalam frames, adapter renderer, validasi dengan skrip, dan - hanya bila diminta dan target diketahui - kode renderer (mis. Remotion/React) serta kesiapan render. Gunakan untuk membuat atau memvalidasi scene manifest, menghitung frame, atau menyiapkan kode renderer video kesehatan. English - renderer-neutral manifest, validation, and renderer adapter/code.
---

# Promkes — Renderer Script & Code (S10)

Prasyarat: 06, 07, 08, 09 DONE (09 boleh SKIPPED). Baca `scenes.json`, `motion_spec.json`, `references.json`, `audio_assets.json`.

## A. Renderer-Neutral Manifest → `10_renderer/manifest.json` (OUTPUT 13)
Kontrak: `promkes-orchestrator/references/manifest.schema.json`; contoh: `manifest.example.json`. Isi: konfigurasi proyek, urutan scene, durasi, FPS, rentang frame, asset ID, reference ID, motion refs, layer ID dan z-order, transform, data overlay, subtitle cues, audio cues, transisi, referensi kontinuitas.
1. **Satu sumber timing**: `scene_timing` (frames kanonis, half-up, half-open). `scene_sequence` tidak boleh memuat timing. Jangan menyimpan timestamp yang bertentangan di dua tempat. Hitung frame dengan `promkes_validate.py frames`.
2. `timing_basis` jujur (PLANNED / ESTIMATED / MEASURED).
3. `reference_assets[*].lifecycle` harus selaras dengan keberadaan berkas (`file_present`, `file_path`, `sha256`).
4. `adapter_status = NOT_CHECKED` dan `render_readiness = HANDOFF` sampai adapter benar-benar diperiksa. `capability_status` disalin dari state.
5. **Klaim "tervalidasi mesin" hanya sah setelah validator dijalankan**:
```bash
python tools/promkes_validate.py manifest 10_renderer/manifest.json --root . --claims 02_health/health_truth_registry.json
```
FAIL → perbaiki di pemilik datanya (berkas scenes, referensi, atau audio), bukan hanya di manifest; WARN → ungkapkan di handoff.

## B. Renderer Adapter → `10_renderer/adapter_check.md`
Identifikasi platform sesungguhnya; periksa platform, versi, komponen/interface, input schema, dependensi, asset path, render route, export capability. Daftar periksa dan pemetaan konsep: `references/renderer-adapters.md`. Target belum ditentukan → hanya manifest renderer-neutral; kode spesifik-platform ditandai NOT_CHECKED.

## C. Renderer Code (hanya bila diminta **dan** spesifikasi target cukup)
Pisahkan berkas: konfigurasi proyek · sumber scene/komposisi · asset manifest · konfigurasi motion · overlay & tipografi · integrasi subtitle/audio · renderer adapter · utilitas validasi/tes · README + instruksi eksekusi. Kode harus cocok dengan kontrak input nyata proyek target (JSON generik bukan input schema). Sertakan komentar, penanganan error, daftar dependensi. Pseudocode wajib berlabel. Jangan mengarang command, API, library, atau versi; kode yang belum dikompilasi/dijalankan berstatus UNVERIFIED.

## D. Render Readiness
Pilih satu: NATIVE, PROGRAMMATIC, HANDOFF, NONE. Render hanya bila runtime, akses berkas, dependensi, hak akses, dan ekspor benar-benar tersedia (lihat `capabilities`); lakukan proof render (satu still atau klip pendek) sebelum render penuh. Jangan mengklaim MP4 tanpa berkas nyata.

## Setelah selesai
`complete 10 --artifact 10_renderer/manifest.json --artifact 10_renderer/adapter_check.md --lock MANIFEST_LOCK=v1`
