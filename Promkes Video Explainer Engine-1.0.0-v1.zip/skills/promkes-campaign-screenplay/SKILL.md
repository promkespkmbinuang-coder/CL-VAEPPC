---
name: promkes-campaign-screenplay
description: Fase 03-04 pipeline promkes. (S03) Arsitektur kampanye - audiens, tujuan pengetahuan/sikap/perilaku, satu pesan inti, hook, arah emosi, CTA; (S04) treatment, logline, struktur naratif, screenplay, naskah VO, dialog, on-screen copy, subtitle transcript dengan estimasi kata-ke-durasi dan setiap pernyataan faktual terhubung claim ID. Gunakan setelah Fact Lock untuk menulis brief, naskah, atau VO video promosi kesehatan. English - campaign brief and screenplay/VO for health-promotion explainers.
---

# Promkes — Campaign Architecture (S03) & Screenplay (S04)

Prasyarat: `FACT_LOCK` (Fase 02 DONE). Baca hanya `02_health/*` dan, untuk Fase 04, `03_campaign/creative_brief.md`.

## Fase 03 → `03_campaign/creative_brief.md` (OUTPUT 03)
Isi brief: audiens dan niche (literasi, konteks, kebutuhan) · masalah komunikasi · tujuan pengetahuan/sikap/perilaku (satu **perilaku prioritas**) · **satu pesan inti** (pesan tambahan tidak boleh menenggelamkannya) · hook · arah emosi (empatik; tidak menakut-nakuti, tidak mempermalukan) · CTA konkret dan aman yang terhubung ke claim ID · gaya bahasa (membumi, komunikatif, tidak menggurui, sesuai audiens) · adaptasi budaya lokal tanpa mengarang dialek atau stereotip · daftar hal yang **tidak** boleh disampaikan (dari klaim yang ditahan). Variabel: `set-var KEY_MESSAGE`, `CTA`, `TARGET_AUDIENCE`, `COMMUNICATION_OBJECTIVE`.

## Fase 04 → `04_screenplay/` (OUTPUT 04)
Bangun: treatment kreatif, logline, premis, struktur (hook → konteks/konflik → insight → resolusi/aksi → CTA), VO, dialog, scene breakdown.

**Pisahkan lima lapisan teks ke lima berkas** (agar tidak saling menimpa): `original_script.md` (naskah asli pengguna, tidak diubah) · `screenplay.md` (hasil edit) · `vo_script.md` (VO yang disetujui) · `onscreen_copy.md` · `subtitle_transcript.md`.

**Keterhubungan fakta**: setiap kalimat faktual diberi penanda `[CLM-NNN]` dan hanya memakai Safe Wording dari Fact Lock. Fakta BELUM_DIVERIFIKASI tidak boleh diperkuat lewat metafora, dramatisasi, atau angka tambahan.

**Estimasi durasi** (wajib realistis): hitung kata VO per scene; `detik ≈ kata / wps + jeda`, dengan `wps` heuristik di `promkes-orchestrator/references/variables-enums-defaults.md` §3 (berlabel ESTIMATED sampai diukur dari sampel nyata). Tabel ringkas: scene · beat · kata · detik estimasi · claim. Bila total tidak muat `VIDEO_DURATION`, revisi pacing atau durasi — jangan menjejalkan dialog.

## Setelah selesai
```bash
python tools/promkes_state.py complete 03 --artifact 03_campaign/creative_brief.md
python tools/promkes_state.py complete 04 --artifact 04_screenplay/screenplay.md --artifact 04_screenplay/vo_script.md --artifact 04_screenplay/onscreen_copy.md --artifact 04_screenplay/subtitle_transcript.md --artifact 04_screenplay/original_script.md --lock SCREENPLAY_LOCK=v1
```
Gerbang G-B: tidak ada kalimat faktual tanpa claim ID; durasi estimasi ≈ target; satu pesan inti jelas.

## Larangan
Menambah klaim yang tidak ada di registry · memakai ketakutan, stigma, atau rasa malu sebagai motor cerita · menjanjikan kesembuhan atau pencegahan absolut · mengarang dialek, nama, atau institusi · mengalihkan fokus ke copywriting media sosial (itu Fase 11, opsional).
