---
name: promkes-visual-continuity
description: Fase 05 pipeline promkes. (S05) Master Visual Style Guide - gaya seni, palet, bahasa bentuk, karakter, kostum, ekspresi, pose, lingkungan, properti, pencahayaan, tekstur; (S13) Master Continuity Guide, ID kanonis, version lock, tujuh Guide, dan change-impact. Gunakan untuk mengunci identitas visual dan kontinuitas karakter/lingkungan video explainer kesehatan, atau ketika aset kanonis berubah. English - visual identity, canonical IDs, and continuity locking.
---

# Promkes — Visual Identity (S05) & Continuity Guardian (S13)

Prasyarat: Fase 04 DONE. Baca `03_campaign/creative_brief.md` dan `04_screenplay/screenplay.md`.

## Keluaran
`05_visual/visual_style_guide.md` (OUTPUT 05) · `05_visual/mcg.json` (OUTPUT 06; bentuk di `promkes-orchestrator/references/ids-traceability-records.md` §3) · `05_visual/guides/*.md` hanya pada ADVANCED.

## Spesifikasi kanonis (S05 menulis; wajib lengkap)
Art style · palet (hex + peran warna) · bahasa bentuk · anatomi dan proporsi karakter · kostum · ekspresi · pose · lingkungan · properti · pencahayaan · tekstur · gaya render. Setiap karakter, lingkungan, properti, dan gaya punya **ID stabil** (`CHR-`, `ENV-`, `PRP-`, `STY-`) dan versi (`@v1`). Gaya diturunkan dari arahan kreatif yang disetujui (`ART_DIRECTION`); tulis juga **risiko drift identitas** dan `allowed_variations` (apa yang boleh berubah antarreferensi) karena tidak ada model yang menjamin identitas sempurna.

## Master Continuity Guide (S13 mengindeks; tidak menulis ulang guide milik spesialis)
| Depth | Isi |
|---|---|
| LITE | MCG-Lite: `mcg.json` + satu style guide; tujuh Guide cukup berupa bagian di dokumen itu |
| STANDARD | + ledger kontinuitas scene (`scene_continuity`) dan registri aset |
| ADVANCED | tujuh Guide penuh di `guides/`, change-impact terjadwal, regression check |

Tujuh Guide (usulan pemilik oleh plugin; spesifikasi tidak menetapkan): **MCHG** Master Character Guide (S05) · **MCPG** Character/Personality Profile (S05 dengan masukan S04) · **MVSG** Master Visual Style Guide (S05) · **MNSG** Master Narrative Style Guide (S04) · **MVAG** Master Voice & Audio Guide (S09) · **MWEG** Master World & Environment Guide (S05) · **SCG** Scene Continuity Guide (S13 dengan masukan S06).

## Perubahan kanon
Mengubah karakter/lingkungan/gaya kanonis = **bump versi** + entri `change_log` (dari, ke, dampak, alasan) + `touch 05 --reason "CHR-01 v1→v2"`. Fase 06+ yang DONE otomatis STALE; jalankan ulang hanya itu. Jangan mengubah karakter kanonis secara diam-diam.

## Setelah selesai
```bash
python tools/promkes_state.py complete 05 --artifact 05_visual/visual_style_guide.md --artifact 05_visual/mcg.json --lock STYLE_LOCK=v1 --lock CONTINUITY_LOCK=v1
```

## Larangan
Membuat logo atau identitas institusi tanpa otorisasi · mengandalkan tipografi AI untuk teks faktual (teks faktual = overlay renderer) · menyatakan identitas visual pasti terjaga · mencampur gaya antarreferensi tanpa mencatat versi.
