---
name: qa
description: Jalankan QA independen dan validator pada paket promkes (package check, manifest, selftest), lalu tulis laporan QA dan defect register. Gunakan ketika pengguna mengetik /promkes:qa atau meminta memeriksa atau mengaudit paket produksi promkes.
---

# /promkes:qa

Argumen pengguna (abaikan bila tertulis literal `$ARGUMENTS`): $ARGUMENTS

Ikuti skill `promkes-qa-handoff`:
1. Temukan proyek (lihat `/promkes:resume` langkah 1). Jalankan `tools/selftest.py` sekali per sesi untuk membuktikan toolbox sehat.
2. Jalankan `promkes_validate.py package` dan, bila `10_renderer/manifest.json` ada, `manifest … --root . --claims …`.
3. Bila sub-agent `promkes-qa-auditor` tersedia, delegasikan uji semantik kepadanya (konteks bersih, hanya berkas di disk); bila tidak, kerjakan dari berkas dan nyatakan batas independensinya.
4. Tulis `12_qa/qa_report.md`, `qa_matrix.json`, `defects.json`. Status jujur: tidak ada NOT_RUN/NOT_VERIFIED/PARTIAL yang berubah menjadi PASS.
5. Tampilkan ringkasan: jumlah FAIL/WARN, defect terbuka per severity, *ceiling* status pengiriman, dan apa yang belum dijalankan.
