---
name: promkes-audio-subtitle
description: Fase 09 dan 11 pipeline promkes (S09, S11). Rekayasa audio - pemeriksaan audio/transkrip dan provenance, kelas presisi timing (WORD/PHRASE/SEGMENT/ESTIMATED/NONE), arahan VO, pelafalan, jeda, SFX, BGM, ambience, subtitle, dan status hak; serta materi aksesibilitas/distribusi opsional (judul, caption, alt text, catatan subtitle). Gunakan untuk audio, voice-over, dan subtitle video kesehatan. English - audio, VO, subtitle timing provenance, and optional distribution copy.
---

# Promkes — Audio (S09) & Aksesibilitas/Distribusi (S11, kondisional)

## Fase 09 → `09_audio/audio_spec.md`, `audio_assets.json` (OUTPUT 15)
Prasyarat: 04 dan 06 DONE.
1. **Cek kemampuan sebelum klaim**: audio decode, metadata, ASR, diarization, alignment (dari `capabilities`: VERIFIED / UNAVAILABLE / NOT_TESTED). Jalankan ASR, diarization, atau alignment hanya bila VERIFIED; tanpa itu jangan mengaku sudah mentranskripsi atau menyelaraskan.
2. **Provenance transkrip**: asal (diberikan pengguna / alat ASR tertentu / ditulis dari screenplay), tanggal, kualitas. Jangan mengarang transkrip atau timecode; jangan menebak identitas speaker.
3. **Kelas presisi timing** per butir: WORD / PHRASE / SEGMENT / ESTIMATED / NONE. SRT/VTT hanya dari timecode yang dapat dipertanggungjawabkan (WORD, PHRASE, SEGMENT terukur). Pada ESTIMATED/NONE subtitle tetap ada sebagai cue rencana, tetapi ekspor SRT/VTT ditahan (validator `SUBTITLE_TIMING_NOT_EXPORTABLE`); presisi subtitle tidak boleh melebihi presisi audionya (`SUBTITLE_PRECISION_EXCEEDS_AUDIO`).
4. **Arahan VO**: gaya (hangat, natural, jelas, percakapan), tempo (wps heuristik berlabel ESTIMATED sampai diukur), jeda dan penekanan, **daftar pelafalan** (istilah medis, nama lokal, singkatan), kalimat yang berat diucapkan.
5. **SFX / BGM / Ambience**: cue per scene (rujuk scene ID), karakter suara, level relatif. Musik tidak boleh dianggap berlisensi: `rights_status` = UNKNOWN sampai ada bukti (asli/dibuat, berlisensi, atau milik pengguna).
6. **Hak suara**: tidak meniru suara orang nyata tanpa hak dan izin. Media pribadi tidak dikirim ke layanan eksternal tanpa otorisasi.
7. `audio_assets.json` = `{"audio_assets":[…],"subtitle_cues":[…]}` dengan field persis seperti di `manifest.schema.json` (frame = frames kanonis dari timeline scene).

`complete 09 --artifact 09_audio/audio_spec.md --artifact 09_audio/audio_assets.json`

## Fase 11 — Aksesibilitas & distribusi (kondisional; default SKIPPED)
Aktifkan dengan `begin 11` hanya bila diminta. Keluaran: judul, caption, alt text, catatan subtitle, hashtag relevan, pengemasan per platform — selaras dengan pesan inti dan Fact Lock, tanpa klaim baru. **Jangan menjanjikan viralitas, FYP, atau engagement.** Ini bukan keluaran utama.

## Larangan
Mengarang transkrip/timecode · menebak speaker · SRT/VTT dari timing ESTIMATED · meniru suara orang nyata · menganggap musik berlisensi · menambah klaim kesehatan baru di caption.
